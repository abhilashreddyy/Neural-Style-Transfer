(window["canvasWebpackJsonp"]=window["canvasWebpackJsonp"]||[]).push([[90],{"58Nq":function(t,e){let i=0
function n(t){return r(s(o(t)))}function s(t){return h(p(a(t),8*t.length))}function r(t){const e=i?"0123456789ABCDEF":"0123456789abcdef"
let n=""
let s
for(let i=0;i<t.length;i++){s=t.charCodeAt(i)
n+=e.charAt(s>>>4&15)+e.charAt(15&s)}return n}function o(t){let e=""
let i=-1
let n,s
while(++i<t.length){n=t.charCodeAt(i)
s=i+1<t.length?t.charCodeAt(i+1):0
if(n>=55296&&n<=56319&&s>=56320&&s<=57343){n=65536+((1023&n)<<10)+(1023&s)
i++}n<=127?e+=String.fromCharCode(n):n<=2047?e+=String.fromCharCode(192|n>>>6&31,128|63&n):n<=65535?e+=String.fromCharCode(224|n>>>12&15,128|n>>>6&63,128|63&n):n<=2097151&&(e+=String.fromCharCode(240|n>>>18&7,128|n>>>12&63,128|n>>>6&63,128|63&n))}return e}function a(t){const e=Array(t.length>>2)
for(var i=0;i<e.length;i++)e[i]=0
for(i=0;i<8*t.length;i+=8)e[i>>5]|=(255&t.charCodeAt(i/8))<<i%32
return e}function h(t){let e=""
for(let i=0;i<32*t.length;i+=8)e+=String.fromCharCode(t[i>>5]>>>i%32&255)
return e}function p(t,e){t[e>>5]|=128<<e%32
t[14+(e+64>>>9<<4)]=e
let i=1732584193
let n=-271733879
let s=-1732584194
let r=271733878
for(let e=0;e<t.length;e+=16){const o=i
const a=n
const h=s
const p=r
i=c(i,n,s,r,t[e+0],7,-680876936)
r=c(r,i,n,s,t[e+1],12,-389564586)
s=c(s,r,i,n,t[e+2],17,606105819)
n=c(n,s,r,i,t[e+3],22,-1044525330)
i=c(i,n,s,r,t[e+4],7,-176418897)
r=c(r,i,n,s,t[e+5],12,1200080426)
s=c(s,r,i,n,t[e+6],17,-1473231341)
n=c(n,s,r,i,t[e+7],22,-45705983)
i=c(i,n,s,r,t[e+8],7,1770035416)
r=c(r,i,n,s,t[e+9],12,-1958414417)
s=c(s,r,i,n,t[e+10],17,-42063)
n=c(n,s,r,i,t[e+11],22,-1990404162)
i=c(i,n,s,r,t[e+12],7,1804603682)
r=c(r,i,n,s,t[e+13],12,-40341101)
s=c(s,r,i,n,t[e+14],17,-1502002290)
n=c(n,s,r,i,t[e+15],22,1236535329)
i=d(i,n,s,r,t[e+1],5,-165796510)
r=d(r,i,n,s,t[e+6],9,-1069501632)
s=d(s,r,i,n,t[e+11],14,643717713)
n=d(n,s,r,i,t[e+0],20,-373897302)
i=d(i,n,s,r,t[e+5],5,-701558691)
r=d(r,i,n,s,t[e+10],9,38016083)
s=d(s,r,i,n,t[e+15],14,-660478335)
n=d(n,s,r,i,t[e+4],20,-405537848)
i=d(i,n,s,r,t[e+9],5,568446438)
r=d(r,i,n,s,t[e+14],9,-1019803690)
s=d(s,r,i,n,t[e+3],14,-187363961)
n=d(n,s,r,i,t[e+8],20,1163531501)
i=d(i,n,s,r,t[e+13],5,-1444681467)
r=d(r,i,n,s,t[e+2],9,-51403784)
s=d(s,r,i,n,t[e+7],14,1735328473)
n=d(n,s,r,i,t[e+12],20,-1926607734)
i=l(i,n,s,r,t[e+5],4,-378558)
r=l(r,i,n,s,t[e+8],11,-2022574463)
s=l(s,r,i,n,t[e+11],16,1839030562)
n=l(n,s,r,i,t[e+14],23,-35309556)
i=l(i,n,s,r,t[e+1],4,-1530992060)
r=l(r,i,n,s,t[e+4],11,1272893353)
s=l(s,r,i,n,t[e+7],16,-155497632)
n=l(n,s,r,i,t[e+10],23,-1094730640)
i=l(i,n,s,r,t[e+13],4,681279174)
r=l(r,i,n,s,t[e+0],11,-358537222)
s=l(s,r,i,n,t[e+3],16,-722521979)
n=l(n,s,r,i,t[e+6],23,76029189)
i=l(i,n,s,r,t[e+9],4,-640364487)
r=l(r,i,n,s,t[e+12],11,-421815835)
s=l(s,r,i,n,t[e+15],16,530742520)
n=l(n,s,r,i,t[e+2],23,-995338651)
i=f(i,n,s,r,t[e+0],6,-198630844)
r=f(r,i,n,s,t[e+7],10,1126891415)
s=f(s,r,i,n,t[e+14],15,-1416354905)
n=f(n,s,r,i,t[e+5],21,-57434055)
i=f(i,n,s,r,t[e+12],6,1700485571)
r=f(r,i,n,s,t[e+3],10,-1894986606)
s=f(s,r,i,n,t[e+10],15,-1051523)
n=f(n,s,r,i,t[e+1],21,-2054922799)
i=f(i,n,s,r,t[e+8],6,1873313359)
r=f(r,i,n,s,t[e+15],10,-30611744)
s=f(s,r,i,n,t[e+6],15,-1560198380)
n=f(n,s,r,i,t[e+13],21,1309151649)
i=f(i,n,s,r,t[e+4],6,-145523070)
r=f(r,i,n,s,t[e+11],10,-1120210379)
s=f(s,r,i,n,t[e+2],15,718787259)
n=f(n,s,r,i,t[e+9],21,-343485551)
i=y(i,o)
n=y(n,a)
s=y(s,h)
r=y(r,p)}return Array(i,n,s,r)}function u(t,e,i,n,s,r){return y(v(y(y(e,t),y(n,r)),s),i)}function c(t,e,i,n,s,r,o){return u(e&i|~e&n,t,e,s,r,o)}function d(t,e,i,n,s,r,o){return u(e&n|i&~n,t,e,s,r,o)}function l(t,e,i,n,s,r,o){return u(e^i^n,t,e,s,r,o)}function f(t,e,i,n,s,r,o){return u(i^(e|~n),t,e,s,r,o)}function y(t,e){const i=(65535&t)+(65535&e)
const n=(t>>16)+(e>>16)+(i>>16)
return n<<16|65535&i}function v(t,e){return t<<e|t>>>32-e}t.exports={encrypt:n}},VAKy:function(t,e,i){"use strict"
n.decorate=function(t){t.messenger=new n
t.addEventListener=function(e,i){t.messenger.addEventListener(e,i)}
t.dispatchEvent=function(e,i,n){t.messenger.dispatchEvent(e,i,n)}
t.removeEventListener=function(e,i){t.messenger.removeEventListener(e,i)}}
function n(){this.events={}}n.prototype.killAllListeners=function(t){if(!this.events[t])return false
this.events[t]=[]}
n.prototype.destroy=function(){this.events={}}
n.prototype.dispatchEvent=function(t,e,i){this.events[t]&&this.events[t].forEach(t=>{t.call(i,e)})}
n.prototype.addEventListener=function(t,e){if(!e)return false
this.events[t]||(this.events[t]=[])
this.events[t].push(e)
return e}
n.prototype.removeEventListener=function(t,e){if(this.events[t]){const i=this.events[t]
const n=[]
this.events[t].forEach((t,i)=>{t===e&&n.push(i)})
n.length>0&&n.forEach(t=>{i.splice(t,1)})}}
var s=n
var r=new s
function o(){}o.prototype.parseXML=function(t){this.$xml=$(t)
this.determineError()
return this.$xml}
o.prototype.determineError=function(){this.isError=!!this.find("error").children().length}
o.prototype.find=function(t){return this.$xml.find(t)}
o.prototype.findRecursive=function(t){t=t.split(":")
let e=this.$xml
let i
for(let n=0,s=t.length;n<s;n++){i=e.find(t[n])[0]
if(!i){e=void 0
break}e=$(i)}return e}
o.prototype.nodeText=function(t,e,i){let n
if(""!=e.find(t).text()){n=e.find(t).text()
true===i&&(n=parseFloat(n))}return n}
var a=o
function h(){this.xml=void 0
this.isError=true
this.token=void 0
this.filename=""
this.fileId=-1
this.xmlParser=new a}h.prototype.parseXML=function(t){this.xmlParser.parseXML(t)
this.isError=this.xmlParser.isError
this.xmlParser.isError||this.pullData()}
h.prototype.pullData=function(){const t=this.xmlParser.find("result_ok")
this.token=this.xmlParser.nodeText("token",t,true)
this.fileId=this.xmlParser.nodeText("filename",t,true)
this.filename=this.xmlParser.nodeText("origFilename",t)}
h.prototype.asEntryParams=function(){return{entry1_name:this.filename,entry1_filename:this.fileId,entry1_realFilename:this.filename}}
var p=h
var u=i("58Nq")
var c=i.n(u)
var d=function(t){let e=[]
for(const i in t)e.push(i)
e=e.sort()
let i=""
e.forEach(e=>{i+=e
i+=t[e]})
return c.a.encrypt(i)}
var l=function(t){let e="?"
for(const i in t)e+=i+"="+encodeURIComponent(t[i])+"&"
e=e.substring(0,e.length-1)
return e}
function f(t,e){return t&&void 0!==t[e]}var y=function(t,e,i){f(i,t)&&(e[t]=i[t])}
function v(){}v.prototype.setOptions=function(t){this.mergeDefaults(t)}
v.prototype.mergeDefaults=function(t){this.allowedMediaTypes=["video","audio"]
this.sessionUrl="/api/v1/services/kaltura_session"
this.uploadUrl=""
this.entryUrl=""
this.uiconfUrl=""
this.entryDefaults={partnerData:"{'context_code': 'some_course_num', 'root_account'_id':1}",conversionProfile:2,source:1,kshow_id:-1,quick_edit:true}
y("allowedMediaTypes",this,t)
y("sessionUrl",this,t)
y("uploadUrl",this,t)
y("entryUrl",this,t)
y("uiconfUrl",this,t)
y("partnerData",this.entryDefaults,t.entryDefaults)
y("conversionProfile",this.entryDefaults,t.entryDefaults)
y("source",this.entryDefaults,t.entryDefaults)
y("kshow_id",this.entryDefaults,t.entryDefaults)
y("quick_edit",this.entryDefaults,t.entryDefaults)}
v.prototype.asEntryParams=function(){return{entry1_partnerData:this.entryDefaults.partnerData,entry1_conversionProfile:this.entryDefaults.conversionProfile,entry1_source:this.entryDefaults.source,kshow_id:this.entryDefaults.kshow_id,quick_edit:this.entryDefaults.quick_edit}}
var m=new v
function x(){this.settings,this.file
this.xhr}x.id=1
x.prototype.createRequest=function(){const t=new XMLHttpRequest
t.open("POST",this.createUrl())
t.responseType="xml"
return t}
x.prototype.createFormData=function(){const t=new FormData
t.append("Filename",this.file.name)
t.append("Filedata",this.file)
t.append("Upload","Submit Query")
return t}
x.prototype.createFileId=function(){x.id+=1
return Date.now().toString()+x.id.toString()}
x.prototype.createUrl=function(){const t=this.settings.getSession()
t.filename=this.createFileId()
t.kalsig=this.createSignature()
return m.uploadUrl+l(t)}
x.prototype.createSignature=function(){return d(this.settings.getSession())}
x.prototype.buildRequest=function(t,e){this.settings=t
this.file=e
return this.createRequest()}
x.prototype.getFile=function(){return this.file}
x.prototype.getSettings=function(){return this.settings}
var E=x
function g(){this.xhr=new XMLHttpRequest
this.uploadResult=new p}g.prototype.isAvailable=function(){return!!this.xhr.upload}
g.prototype.send=function(t,e){const i=new E
this.xhr=i.buildRequest(t,e)
this.addEventListeners()
this.xhr.send(i.createFormData())}
g.prototype.addEventListeners=function(){this.xhr.upload.addEventListener("progress",this.eventProxy.bind(this.xhr))
this.xhr.upload.addEventListener("load",this.eventProxy.bind(this.xhr))
this.xhr.upload.addEventListener("error",this.eventProxy.bind(this.xhr))
this.xhr.upload.addEventListener("abort",this.eventProxy.bind(this.xhr))
this.xhr.onload=this.onload.bind(this)}
g.prototype.onload=function(t){this.uploadResult.parseXML(this.xhr.response)
const e=this.uploadResult.isError?"error":"success"
r.dispatchEvent("Uploader."+e,this.uploadResult)}
g.prototype.eventProxy=function(t){const e="Uploader."+t.type
r.dispatchEvent(e,t,this)}
var S=g
function b(){this.ks=""
this.subp_id=""
this.partner_id=""
this.uid=""
this.serverTime=0}b.prototype.setSession=function(t){if(t){y("ks",this,t)
y("subp_id",this,t)
y("partner_id",this,t)
y("uid",this,t)
y("serverTime",this,t)
y("ui_conf_id",this,t)}}
b.prototype.getSession=function(){return{ks:this.ks,subp_id:this.subp_id,partner_id:this.partner_id,uid:this.uid,serverTime:this.serverTime,ui_conf_id:this.ui_conf_id}}
b.prototype.asEntryParams=function(){return this.getSession()}
var L=b
function w(){this.sessionData=new L}w.prototype.loadSession=function(){const t=new XMLHttpRequest
t.open("POST",m.sessionUrl,true)
t.responseType="json"
t.onload=this.onSessionLoaded.bind(this)
t.send()}
w.prototype.onSessionLoaded=function(t){const e=t.target
if(200==e.status){this.sessionData.setSession(e.response)
r.dispatchEvent("SessionManager.complete",this.sessionData,this)}else r.dispatchEvent("SessionManager.error")}
w.prototype.getSession=function(){return this.sessionData}
var F=function(t){if(!t)return t
const e={}
t=t.reverse()
t.forEach(t=>{for(const i in t)e[i]=t[i]})
return e}
function U(){this.xmlParser=new a}U.prototype.addEntry=function(t){this.formData=F(t)
this.createEntryRequest()}
U.prototype.createEntryRequest=function(){const t=this.formData
t.kalsig=d(t)
this.xhr=new XMLHttpRequest
this.xhr.open("GET",m.entryUrl+l(t))
this.xhr.requestType="xml"
this.xhr.onload=this.onEntryRequestLoaded.bind(this)
this.xhr.send(t)}
U.prototype.onEntryRequestLoaded=function(t){this.xmlParser.parseXML(this.xhr.response)
var e=this.xmlParser.findRecursive("result:entries:entry1_")
if(e){e={id:e.find("id").text(),type:e.find("type").text(),title:e.find("name").text(),context_code:e.find("partnerData").text(),mediaType:e.find("mediatype").text(),entryId:e.find("id").text(),userTitle:void 0}
r.dispatchEvent("Entry.success",e,this)}else r.dispatchEvent("Entry.fail",this.xhr.response,this)}
var _=U
function P(t){this.fileFilters=[]
this.maxUploads=t.maxUploads
this.maxFileSize=t.maxFileSize
this.maxTotalSize=t.maxTotalSize}P.prototype.addFileFilter=function(t){this.fileFilters.push(t)}
P.prototype.filterFor=function(t){let e,i
const n=t.split(".").pop()
for(let t=0,s=this.fileFilters.length;t<s;t++){i=this.fileFilters[t]
if(i.includesExtension(n)){e=i
break}}return e}
P.prototype.asEntryParams=function(t){const e=this.filterFor(t)
return e.toParams()}
P.prototype.acceptableFileSize=function(t){return 1024*this.maxFileSize*1024>t}
P.prototype.acceptableFileType=function(t,e){const i=this.filterFor(t)
if(!i)return false
return-1!==e.indexOf(i.id)}
P.prototype.acceptableFile=function(t,e){const i=this.acceptableFileType(t.name,e)
const n=this.acceptableFileSize(t.size)
return i&&n}
var T=P
function D(t){this.extensions=this.parseExtensions(t.extensions)
this.id=t.id
this.description=t.description
this.entryType=t.entryType
this.mediaType=t.mediaType
this.type=t.type}D.prototype.parseExtensions=function(t){return t.split(";").map(t=>t.substring(2))}
D.prototype.includesExtension=function(t){return-1!==this.extensions.indexOf(t.toLowerCase())}
D.prototype.toParams=function(){const t={entry1_type:this.entryType,entry1_mediaType:this.mediaType}
return t}
var C=D
var k=function(t){return new C({id:t.getAttribute("id"),description:t.getAttribute("description"),entryType:t.getAttribute("entryType"),mediaType:t.getAttribute("mediaType"),type:t.getAttribute("type"),extensions:t.getAttribute("extensions")})}
var q=function(t){const e=t.find("limits")
const i=new T({maxUploads:e.attr("maxUploads"),maxFileSize:e.attr("maxFileSize"),maxTotalSize:e.attr("maxTotalSize")})
const n=t.find("fileFilters").children()
for(let t=0,e=n.length;t<e;t++){const e=k(n[t])
i.addFileFilter(e)}return i}
function R(){this.xmlParser=new a}R.prototype.load=function(t){const e=t.getSession()
e.kalsig=d(e)
this.xhr=new XMLHttpRequest
this.xhr.open("GET",m.uiconfUrl+l(e))
this.xhr.addEventListener("load",this.onXhrLoad.bind(this))
this.xhr.send(e)}
R.prototype.createUiConfig=function(t){this.config=q(t)}
R.prototype.onXhrLoad=function(t){this.xmlParser.parseXML(this.xhr.response)
const e=this.xmlParser.find("result").find("ui_conf").find("confFile").first().text()
if(e){this.xmlParser=new a
this.xmlParser.parseXML(e)
this.config=q(this.xmlParser)
r.dispatchEvent("UiConf.complete",this.config,this)}else r.dispatchEvent("UiConf.error",this.xhr.response,this)}
var M=R
function A(t){s.decorate(this)
m.setOptions(t)
this.buildDependencies()
this.addListeners()
this.session.setSession(t.kaltura_session)
this.loadUiConf()}A.prototype.destroy=function(){r.destroy()
this.session=void 0
this.entryService=void 0
this.uiconfService=void 0}
A.prototype.buildDependencies=function(){this.session=new L
this.entryService=new _
this.uiconfService=new M}
A.prototype.addListeners=function(){r.addEventListener("UiConf.error",this.onUiConfError.bind(this))
r.addEventListener("UiConf.complete",this.onUiConfComplete.bind(this))
r.addEventListener("Uploader.error",this.onUploadError.bind(this))
r.addEventListener("Uploader.success",this.onUploadSuccess.bind(this))
r.addEventListener("Uploader.progress",this.onProgress.bind(this))
r.addEventListener("Entry.success",this.onEntrySuccess.bind(this))
r.addEventListener("Entry.fail",this.onEntryFail.bind(this))}
A.prototype.onSessionLoaded=function(t){this.session=t
this.loadUiConf()}
A.prototype.loadUiConf=function(){this.uiconfService.load(this.session)}
A.prototype.onUiConfComplete=function(t){this.uiconfig=t
this.dispatchEvent("K5.ready",{},this)}
A.prototype.uploadFile=function(t){this.file=t
if(!t)return
if(this.uiconfig.acceptableFile(t,m.allowedMediaTypes)||["webm","video/webm","audio/webm"].includes(t.type)){this.uploader=new S
this.uploader.send(this.session,t)}else{const e={maxFileSize:this.uiconfig.maxFileSize,file:t,allowedMediaTypes:m.allowedMediaTypes}
this.dispatchEvent("K5.fileError",e,this)}}
A.prototype.onUploadSuccess=function(t){const e=[this.session.asEntryParams(),t.asEntryParams(),m.asEntryParams()]
this.entryService.addEntry(e)}
A.prototype.onProgress=function(t){this.dispatchEvent("K5.progress",t,this)}
A.prototype.onUploadError=function(t){this.dispatchEvent("K5.error",t,this)}
A.prototype.onEntrySuccess=function(t){this.dispatchEvent("K5.complete",t,this)}
A.prototype.onEntryFail=function(t){this.dispatchEvent("K5.error",t,this)}
A.prototype.onUiConfError=function(t){this.dispatchEvent("K5.uiconfError",t,this)}
e["a"]=A}}])

//# sourceMappingURL=90-c-7e2ad34923.js.map