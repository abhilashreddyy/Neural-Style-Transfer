(window["canvasWebpackJsonp"]=window["canvasWebpackJsonp"]||[]).push([[50],{"40dz":function(e,t,o){"use strict"
o.r(t)
o.d(t,"default",(function(){return T}))
var c=o("An8g")
var l=o("VTBJ")
var a=o("HGxv")
var i=o("8WeW")
Object(i["a"])(JSON.parse('{"ar":{"there_was_a_problem_toggling_the_content_lock_2a5d678b":"حدثت مشكلة أثناء تبديل قفل المحتوى."},"ca":{"there_was_a_problem_toggling_the_content_lock_2a5d678b":"S\'ha produït un problema en commutar el bloqueig del contingut."},"cy":{"there_was_a_problem_toggling_the_content_lock_2a5d678b":"Problem wrth doglo’r clo cynnwys."},"da":{"there_was_a_problem_toggling_the_content_lock_2a5d678b":"Der opstod et problem, da indholdslåsen blev slået til eller fra."},"da-x-k12":{"there_was_a_problem_toggling_the_content_lock_2a5d678b":"Der opstod et problem, da indholdslåsen blev slået til eller fra."},"de":{"there_was_a_problem_toggling_the_content_lock_2a5d678b":"Es gab ein Problem beim Umschalten der Content-Sperre."},"en-AU":{"there_was_a_problem_toggling_the_content_lock_2a5d678b":"There was a problem toggling the content lock."},"en-AU-x-unimelb":{"there_was_a_problem_toggling_the_content_lock_2a5d678b":"There was a problem toggling the content lock."},"en-CA":{"there_was_a_problem_toggling_the_content_lock_2a5d678b":"There was a problem toggling the content lock."},"en-GB":{"there_was_a_problem_toggling_the_content_lock_2a5d678b":"There was a problem toggling the content lock."},"en-GB-x-lbs":{"there_was_a_problem_toggling_the_content_lock_2a5d678b":"There was a problem toggling the content lock."},"en-GB-x-ukhe":{"there_was_a_problem_toggling_the_content_lock_2a5d678b":"There was a problem toggling the content lock."},"es":{"there_was_a_problem_toggling_the_content_lock_2a5d678b":"Hubo un problema al cambiar el bloqueo de contenido."},"fa":{"there_was_a_problem_toggling_the_content_lock_2a5d678b":"در هنگام تغییر وضعیت قفل محتوا، مشکلی رخ داد."},"fi":{"there_was_a_problem_toggling_the_content_lock_2a5d678b":"Sisällön lukon kanssa ilmeni ongelma."},"fr":{"there_was_a_problem_toggling_the_content_lock_2a5d678b":"L\'activation/désactivation du verrou sur le contenu a rencontré un problème."},"fr-CA":{"there_was_a_problem_toggling_the_content_lock_2a5d678b":"Un problème est survenu lors du basculement du verrouillage de contenu."},"ht":{"there_was_a_problem_toggling_the_content_lock_2a5d678b":"Te gen yon pwoblèm pou regle blokaj kontni an."},"is":{"there_was_a_problem_toggling_the_content_lock_2a5d678b":"Vandamál kom upp við að víxla efnislás."},"it":{"there_was_a_problem_toggling_the_content_lock_2a5d678b":"Si è verificato un problema durante l\'abilitazione/disabilitazione del blocco dei contenuti."},"ja":{"there_was_a_problem_toggling_the_content_lock_2a5d678b":"コンテンツロックをスイッチする際に問題が発生しました。"},"mi":{"there_was_a_problem_toggling_the_content_lock_2a5d678b":"He raruraru i te wā e takahuri ana i te raka ihirangi"},"nb":{"there_was_a_problem_toggling_the_content_lock_2a5d678b":"Det oppstod et problem med veksling av innholdslåsen."},"nb-x-k12":{"there_was_a_problem_toggling_the_content_lock_2a5d678b":"Det oppstod et problem med veksling av innholdslåsen."},"nl":{"there_was_a_problem_toggling_the_content_lock_2a5d678b":"Er is een probleem met het in- en uitschakelen van de inhoudsvergrendeling."},"nn":{"there_was_a_problem_toggling_the_content_lock_2a5d678b":"Kunne ikkje slå av/på innhaldslås"},"pl":{"there_was_a_problem_toggling_the_content_lock_2a5d678b":"Wystąpił problem podczas przełączania blokowania treści."},"pt":{"there_was_a_problem_toggling_the_content_lock_2a5d678b":"Houve um problema ao alternar o bloqueio de conteúdo."},"pt-BR":{"there_was_a_problem_toggling_the_content_lock_2a5d678b":"Houve um problema ao alternar o bloqueio de conteúdo."},"ru":{"there_was_a_problem_toggling_the_content_lock_2a5d678b":"При блокировке/разблокировке содержимого возникла проблема."},"sl":{"there_was_a_problem_toggling_the_content_lock_2a5d678b":"Prišlo je do težave pri preklopu zaklepanja vsebine."},"sv":{"there_was_a_problem_toggling_the_content_lock_2a5d678b":"Det uppstod ett problem med att växla innehållslåset."},"sv-x-k12":{"there_was_a_problem_toggling_the_content_lock_2a5d678b":"Det uppstod ett problem med att växla innehållslåset."},"uk":{"there_was_a_problem_toggling_the_content_lock_2a5d678b":"Виникла проблема з перемиканням блокування зміни контенту"},"zh-Hans":{"there_was_a_problem_toggling_the_content_lock_2a5d678b":"切换课程锁定时出现问题。"},"zh-Hant":{"there_was_a_problem_toggling_the_content_lock_2a5d678b":"切換內容鎖定時出現問題。"}}'))
o("jQeR")
o("0sPK")
var n=a["default"].scoped("blueprint_coursesLockManageer")
var _=o("ouhR")
var r=o.n(_)
var s=o("q1tI")
var k=o("i8i4")
var u=o.n(k)
o("aq8L")
var d=o("mwIZ")
var b=o.n(d)
const p=e=>Object.assign({assignment:{toggleWrapperSelector:{show:".assignment-buttons",edit:".header-bar .header-bar-right .header-group-left"}[e.page],itemIdPath:{show:"ASSIGNMENT_ID",edit:"ASSIGNMENT.id"}[e.page]},quiz:{toggleWrapperSelector:{show:".header-group-left",edit:".header-bar .header-bar-right .header-group-left"}[e.page],toggleWrapperChildIndex:{edit:2}[e.page],itemIdPath:"QUIZ.id"},discussion_topic:{toggleWrapperSelector:{show:".form-inline .pull-right",edit:".discussion-edit-header .text-right"}[e.page],itemIdPath:{show:"DISCUSSION.TOPIC.ID",edit:"DISCUSSION_TOPIC.ATTRIBUTES.id"}[e.page]},wiki_page:{toggleWrapperSelector:{show:".blueprint-label"}[e.page],itemIdPath:"WIKI_PAGE.page_id"}}[e.itemType],e)
var g=p
var f=o("poaC")
Object(i["a"])(JSON.parse('{"ar":{"attributes_locked_1a1a0f46":"%{attributes} مؤمّن","locked_796957c7":"مؤمّن:"},"ca":{"attributes_locked_1a1a0f46":"%{attributes} bloquejats","locked_796957c7":"Bloquejat:"},"cy":{"attributes_locked_1a1a0f46":"%{attributes} wedi\'u cloi","locked_796957c7":"Wedi Cloi:"},"da":{"attributes_locked_1a1a0f46":"%{attributes} låst","locked_796957c7":"Låst:"},"da-x-k12":{"attributes_locked_1a1a0f46":"%{attributes} låst","locked_796957c7":"Låst:"},"de":{"attributes_locked_1a1a0f46":"%{attributes} gesperrt","locked_796957c7":"Gesperrt:"},"en-AU":{"attributes_locked_1a1a0f46":"%{attributes} locked","locked_796957c7":"Locked:"},"en-AU-x-unimelb":{"attributes_locked_1a1a0f46":"%{attributes} locked","locked_796957c7":"Locked:"},"en-CA":{"attributes_locked_1a1a0f46":"%{attributes} locked","locked_796957c7":"Locked:"},"en-GB":{"attributes_locked_1a1a0f46":"%{attributes} locked","locked_796957c7":"Locked:"},"en-GB-x-lbs":{"attributes_locked_1a1a0f46":"%{attributes} locked","locked_796957c7":"Locked:"},"en-GB-x-ukhe":{"attributes_locked_1a1a0f46":"%{attributes} locked","locked_796957c7":"Locked:"},"es":{"attributes_locked_1a1a0f46":"%{attributes} bloqueado","locked_796957c7":"Bloqueado:"},"fa":{"attributes_locked_1a1a0f46":"%{attributes} قفل شده","locked_796957c7":"قفل شده:"},"fi":{"attributes_locked_1a1a0f46":"%{attributes} lukittu","locked_796957c7":"Lukittu:"},"fr":{"attributes_locked_1a1a0f46":"%{attributes} verrouillé","locked_796957c7":"Verrouillé :"},"fr-CA":{"attributes_locked_1a1a0f46":"%{attributes} verrouillé","locked_796957c7":"Verrouillé :"},"he":{"attributes_locked_1a1a0f46":"%{attributes} נעול","locked_796957c7":"נעול:"},"ht":{"attributes_locked_1a1a0f46":"%{attributes} bloke","locked_796957c7":"Bbloke:"},"hu":{"attributes_locked_1a1a0f46":"%{attributes}zárolva"},"is":{"attributes_locked_1a1a0f46":"%{attributes} læst","locked_796957c7":"Læst:"},"it":{"attributes_locked_1a1a0f46":"%{attributes} bloccato","locked_796957c7":"Bloccato:"},"ja":{"attributes_locked_1a1a0f46":"%{attributes} ロックされています","locked_796957c7":"ロックされています"},"mi":{"attributes_locked_1a1a0f46":"%{attributes} Kua rakaina","locked_796957c7":"Kua rakaina:"},"nb":{"attributes_locked_1a1a0f46":"%{attributes} låst","locked_796957c7":"Låst:"},"nb-x-k12":{"attributes_locked_1a1a0f46":"%{attributes} låst","locked_796957c7":"Låst:"},"nl":{"attributes_locked_1a1a0f46":"%{attributes} vergrendeld","locked_796957c7":"Vergrendeld:"},"nn":{"attributes_locked_1a1a0f46":"%{attributes} låste","locked_796957c7":"Låst:"},"pl":{"attributes_locked_1a1a0f46":"%{attributes} zblokowane","locked_796957c7":"Zblokowane:"},"pt":{"attributes_locked_1a1a0f46":"%{attributes} Bloqueado","locked_796957c7":"Bloqueado:"},"pt-BR":{"attributes_locked_1a1a0f46":"%{attributes} bloqueado(a)","locked_796957c7":"Bloqueado(a):"},"ru":{"attributes_locked_1a1a0f46":"%{attributes} заблокировано","locked_796957c7":"Заблокировано:"},"sl":{"attributes_locked_1a1a0f46":"%{attributes} zaklenjeno","locked_796957c7":"Zaklenjeno:"},"sv":{"attributes_locked_1a1a0f46":"%{attributes} låst","locked_796957c7":"Låst:"},"sv-x-k12":{"attributes_locked_1a1a0f46":"%{attributes} låst","locked_796957c7":"Låst:"},"tr":{"attributes_locked_1a1a0f46":"%{attributes} kilitli"},"uk":{"attributes_locked_1a1a0f46":"%{attributes} заблоковано","locked_796957c7":"Заблоковано:"},"zh-Hans":{"attributes_locked_1a1a0f46":"%{attributes} 已锁定","locked_796957c7":"已锁定："},"zh-Hant":{"attributes_locked_1a1a0f46":"%{attributes} 已鎖定","locked_796957c7":"已鎖定："}}'))
var h=a["default"].scoped("blueprint_coursesLockBanner")
o("17x9")
var m=o("L+/K")
var L=o("ZbPE")
o("r2Yr")
var v=o("wOvH")
o("tlDv")
class C extends s["Component"]{static setupRootNode(){const e=document.createElement("div")
e.id="blueprint-lock-banner"
e.setAttribute("style","margin-bottom: 2em")
const t=document.querySelector("#content")
return t.insertBefore(e,t.firstChild)}componentDidUpdate(e){this.props.isLocked&&!e.isLocked&&r.a.screenReaderFlashMessage(h.t("%{attributes} locked",{attributes:Object(v["a"])(this.props.itemLocks)}))}render(){if(this.props.isLocked)return Object(c["a"])(m["a"],{},void 0,Object(c["a"])(L["a"],{weight:"bold",size:"small"},void 0,h.t("Locked:")," "),Object(c["a"])(L["a"],{size:"small"},void 0,Object(v["a"])(this.props.itemLocks)))
return null}}C.defaultProps={itemLocks:{content:false,points:false,settings:false,due_dates:false,availability_dates:false}}
Object(i["a"])(JSON.parse('{"ar":{"blueprint_5cca2ef":"المخطط","lock_c341af13":"تأمين","locked_762f138b":"تم التأمين","locked_click_to_unlock_50747e11":"مؤمّن. انقر لإلغاء التأمين.","unlock_f6196bf5":"إلغاء التأمين","unlocked_click_to_lock_53262ce7":"غير مؤمّن. انقر للتأمين."},"ca":{"blueprint_5cca2ef":"Plantilla","lock_c341af13":"Bloqueja","locked_762f138b":"Bloquejat","locked_click_to_unlock_50747e11":"Bloquejat. Feu clic per desbloquejar.","unlock_f6196bf5":"Desbloqueja","unlocked_click_to_lock_53262ce7":"Desbloquejat. Feu clic per bloquejar."},"cy":{"blueprint_5cca2ef":"Glasbrint","lock_c341af13":"Cloi","locked_762f138b":"Wedi Cloi","locked_click_to_unlock_50747e11":"Wedi Cloi. Cliciwch i ddatgloi.","unlock_f6196bf5":"Datgloi","unlocked_click_to_lock_53262ce7":"Wedi Datgloi. Cliciwch i’w gloi."},"da":{"blueprint_5cca2ef":"Blueprint","lock_c341af13":"Lås","locked_762f138b":"Låst","locked_click_to_unlock_50747e11":"Låst. Klik for at låse op.","unlock_f6196bf5":"Lås op","unlocked_click_to_lock_53262ce7":"Låst op. Klik for at låse."},"da-x-k12":{"blueprint_5cca2ef":"Blueprint","lock_c341af13":"Lås","locked_762f138b":"Låst","locked_click_to_unlock_50747e11":"Låst. Klik for at låse op.","unlock_f6196bf5":"Lås op","unlocked_click_to_lock_53262ce7":"Låst op. Klik for at låse."},"de":{"blueprint_5cca2ef":"Muster","lock_c341af13":"Sperre","locked_762f138b":"Gesperrt","locked_click_to_unlock_50747e11":"Gesperrt. Zum Entsperren klicken","unlock_f6196bf5":"Entsperren","unlocked_click_to_lock_53262ce7":"Entsperrt Zum Sperren klicken"},"el":{"locked_762f138b":"Κλειδωμένο"},"en-AU":{"blueprint_5cca2ef":"Blueprint","lock_c341af13":"Lock","locked_762f138b":"Locked","locked_click_to_unlock_50747e11":"Locked. Click to unlock.","unlock_f6196bf5":"Unlock","unlocked_click_to_lock_53262ce7":"Unlocked. Click to lock."},"en-AU-x-unimelb":{"blueprint_5cca2ef":"Blueprint","lock_c341af13":"Lock","locked_762f138b":"Locked","locked_click_to_unlock_50747e11":"Locked. Click to unlock.","unlock_f6196bf5":"Unlock","unlocked_click_to_lock_53262ce7":"Unlocked. Click to lock."},"en-CA":{"blueprint_5cca2ef":"Blueprint","lock_c341af13":"Lock","locked_762f138b":"Locked","locked_click_to_unlock_50747e11":"Locked. Click to unlock.","unlock_f6196bf5":"Unlock","unlocked_click_to_lock_53262ce7":"Unlocked. Click to lock."},"en-GB":{"blueprint_5cca2ef":"Blueprint","lock_c341af13":"Lock","locked_762f138b":"Locked","locked_click_to_unlock_50747e11":"Locked. Click to unlock.","unlock_f6196bf5":"Unlock","unlocked_click_to_lock_53262ce7":"Unlocked. Click to lock."},"en-GB-x-lbs":{"blueprint_5cca2ef":"Blueprint","lock_c341af13":"Lock","locked_762f138b":"Locked","locked_click_to_unlock_50747e11":"Locked. Click to unlock.","unlock_f6196bf5":"Unlock","unlocked_click_to_lock_53262ce7":"Unlocked. Click to lock."},"en-GB-x-ukhe":{"blueprint_5cca2ef":"Blueprint","lock_c341af13":"Lock","locked_762f138b":"Locked","locked_click_to_unlock_50747e11":"Locked. Click to unlock.","unlock_f6196bf5":"Unlock","unlocked_click_to_lock_53262ce7":"Unlocked. Click to lock."},"es":{"blueprint_5cca2ef":"Proyecto","lock_c341af13":"Bloquear","locked_762f138b":"Bloqueado","locked_click_to_unlock_50747e11":"Bloqueado. Hacer clic para desbloquear.","unlock_f6196bf5":"Desbloquear","unlocked_click_to_lock_53262ce7":"Desbloqueado. Hacer clic para bloquear."},"fa":{"blueprint_5cca2ef":"طرح","lock_c341af13":"قفل کردن","locked_762f138b":"قفل شده","locked_click_to_unlock_50747e11":"قفل شده. برای قفل گشایی کلیک کنید.","unlock_f6196bf5":"قفل گشایی","unlocked_click_to_lock_53262ce7":"قفل گشایی شده. برای قفل کردن کلیک کنید."},"fi":{"blueprint_5cca2ef":"Blueprint","lock_c341af13":"Lukitse","locked_762f138b":"Lukittu","locked_click_to_unlock_50747e11":"Lukittu. Poista lukitus napsauttamalla.","unlock_f6196bf5":"Poista lukitus.","unlocked_click_to_lock_53262ce7":"Lukitus poistettu. Lukitse napsauttamalla."},"fr":{"blueprint_5cca2ef":"Projet","lock_c341af13":"Verrouiller","locked_762f138b":"Verrouillé(e)","locked_click_to_unlock_50747e11":"Verrouillé. Cliquez pour déverrouiller.","unlock_f6196bf5":"Déverrouiller","unlocked_click_to_lock_53262ce7":"Déverrouillé. Cliquez pour verrouiller."},"fr-CA":{"blueprint_5cca2ef":"Modèle","lock_c341af13":"Verrouiller","locked_762f138b":"Verrouillé","locked_click_to_unlock_50747e11":"Verrouillé. Cliquez pour déverrouiller.","unlock_f6196bf5":"Déverrouiller","unlocked_click_to_lock_53262ce7":"Déverrouillé. Cliquez pour verrouiller."},"he":{"blueprint_5cca2ef":"תבנית דוגמה","lock_c341af13":"נעילה","locked_762f138b":"נעול","locked_click_to_unlock_50747e11":"נעול: הקש/י להסרת נעילה"},"ht":{"blueprint_5cca2ef":"Blueprint","lock_c341af13":"Bloke","locked_762f138b":"Bloke","locked_click_to_unlock_50747e11":"Bloke. Klike pou debloke.","unlock_f6196bf5":"Debloke","unlocked_click_to_lock_53262ce7":"Debloke. Klike pou bloke."},"hu":{"blueprint_5cca2ef":"Blueprint","lock_c341af13":"Zárolás","locked_762f138b":"Zárolt","locked_click_to_unlock_50747e11":"Zárolva. Kattintson a zárolás feloldásához.","unlock_f6196bf5":"Zárolás feloldása","unlocked_click_to_lock_53262ce7":"Zárolás feloldva. Kattintson a zároláshoz."},"hy":{"locked_762f138b":"Արգելափակված է"},"is":{"blueprint_5cca2ef":"Blueprint","lock_c341af13":"Læsa","locked_762f138b":"Læst ","locked_click_to_unlock_50747e11":"Læst. Smellið til að opna.","unlock_f6196bf5":"Aflæsa","unlocked_click_to_lock_53262ce7":"Aflæst. Smelltu til að læsa."},"it":{"blueprint_5cca2ef":"Modello di base","lock_c341af13":"Blocca","locked_762f138b":"Bloccato","locked_click_to_unlock_50747e11":"Bloccato. Fai clic per sbloccare.","unlock_f6196bf5":"Sblocca","unlocked_click_to_lock_53262ce7":"Sbloccato. Fai clic per bloccare."},"ja":{"blueprint_5cca2ef":"青写真","lock_c341af13":"ロック","locked_762f138b":"ロックされています","locked_click_to_unlock_50747e11":"ロックされています。クリックしてロック解除する。","unlock_f6196bf5":"ロック解除する","unlocked_click_to_lock_53262ce7":"ロック解除。クリックしてロックする。"},"mi":{"blueprint_5cca2ef":"Tātauira","lock_c341af13":"raka","locked_762f138b":"Kua rakaina","locked_click_to_unlock_50747e11":"Kua rakaina: Pāwhiri ki te huaki","unlock_f6196bf5":"Huaki","unlocked_click_to_lock_53262ce7":"Kua Huakina Pāwhiri ki te huaki"},"nb":{"blueprint_5cca2ef":"Blueprint","lock_c341af13":"Lås","locked_762f138b":"Låst","locked_click_to_unlock_50747e11":"Låst. Klikk for å låse opp.","unlock_f6196bf5":"Lås opp","unlocked_click_to_lock_53262ce7":"Låst opp. Klikk for å låse."},"nb-x-k12":{"blueprint_5cca2ef":"Fagmal","lock_c341af13":"Lås","locked_762f138b":"Låst","locked_click_to_unlock_50747e11":"Låst. Klikk for å låse opp.","unlock_f6196bf5":"Lås opp","unlocked_click_to_lock_53262ce7":"Låst opp. Klikk for å låse."},"nl":{"blueprint_5cca2ef":"Blauwdruk","lock_c341af13":"Vergrendelen","locked_762f138b":"Vergrendeld","locked_click_to_unlock_50747e11":"Vergrendeld. Klik om te ontgrendelen.","unlock_f6196bf5":"Ontgrendelen","unlocked_click_to_lock_53262ce7":"Ontgrendeld. Klik om te vergrendelen."},"nn":{"blueprint_5cca2ef":"Blueprint","lock_c341af13":"Lås","locked_762f138b":"Låst","locked_click_to_unlock_50747e11":"Låst. Klikk for å opne.","unlock_f6196bf5":"Lås opp","unlocked_click_to_lock_53262ce7":"Ulåst. Klikk for å opne. "},"pl":{"blueprint_5cca2ef":"Wzorzec","lock_c341af13":"Zablokuj","locked_762f138b":"Zablokowany","locked_click_to_unlock_50747e11":"Zblokowane. Kliknij, aby odblokować.","unlock_f6196bf5":"Odblokuj","unlocked_click_to_lock_53262ce7":"Odblokowane. Kliknij, aby zablokować."},"pt":{"blueprint_5cca2ef":"Blueprint","lock_c341af13":"Bloquear","locked_762f138b":"Travada","locked_click_to_unlock_50747e11":"Bloqueado, Clique para desbloquear.","unlock_f6196bf5":"Desbloquear","unlocked_click_to_lock_53262ce7":"Desbloqueado. Clique para bloquear."},"pt-BR":{"blueprint_5cca2ef":"Modelo","lock_c341af13":"Bloquear","locked_762f138b":"Bloqueado(a)","locked_click_to_unlock_50747e11":"Bloqueado. Clique para desbloquear.","unlock_f6196bf5":"Desbloquear","unlocked_click_to_lock_53262ce7":"Desbloqueado. Clique para bloquear."},"ru":{"blueprint_5cca2ef":"Шаблон","lock_c341af13":"Заблокировать","locked_762f138b":"Заблокировано","locked_click_to_unlock_50747e11":"Заблокировано. Нажмите, чтобы разблокировать.","unlock_f6196bf5":"Разблокировать","unlocked_click_to_lock_53262ce7":"Разблокировано. Нажмите, чтобы заблокировать."},"sl":{"blueprint_5cca2ef":"Šablona","lock_c341af13":"Zakleni","locked_762f138b":"Zaklenjeno","locked_click_to_unlock_50747e11":"Zaklenjeno. Kliknite, da odklenete.","unlock_f6196bf5":"Odkleni","unlocked_click_to_lock_53262ce7":"Odklenjeno. Kliknite, da zaklenete."},"sv":{"blueprint_5cca2ef":"Modell","lock_c341af13":"Lås","locked_762f138b":"Låst","locked_click_to_unlock_50747e11":"Låst. Klicka för att låsa upp.","unlock_f6196bf5":"Lås upp","unlocked_click_to_lock_53262ce7":"Olåst. Klicka för att låsa."},"sv-x-k12":{"blueprint_5cca2ef":"Modell","lock_c341af13":"Lås","locked_762f138b":"Låst","locked_click_to_unlock_50747e11":"Låst. Klicka för att låsa upp.","unlock_f6196bf5":"Lås upp","unlocked_click_to_lock_53262ce7":"Olåst. Klicka för att låsa."},"tr":{"blueprint_5cca2ef":"Şablon","locked_762f138b":"Kilitli"},"uk":{"blueprint_5cca2ef":"Проект","lock_c341af13":"Заблокувати","locked_762f138b":"Заблоковано","locked_click_to_unlock_50747e11":"Заблоковано. Клацніть, щоб розблокувати.","unlock_f6196bf5":"Розблокувати","unlocked_click_to_lock_53262ce7":"Розблоковано. Натисніть, щоб заблокувати."},"zh-Hans":{"blueprint_5cca2ef":"模板","lock_c341af13":"锁定","locked_762f138b":"已锁定","locked_click_to_unlock_50747e11":"已锁定。单击以解锁。","unlock_f6196bf5":"解锁","unlocked_click_to_lock_53262ce7":"已解锁。单击以锁定。"},"zh-Hant":{"blueprint_5cca2ef":"計劃","lock_c341af13":"鎖定","locked_762f138b":"已鎖定","locked_click_to_unlock_50747e11":"已鎖定。點擊解鎖。","unlock_f6196bf5":"解除鎖定","unlocked_click_to_lock_53262ce7":"已解除鎖定。點擊鎖定。"}}'))
var w=a["default"].scoped("blueprint_coursesLockToggle")
var O=o("Xx/m")
var q=o("Zgll")
var j=o("bZJi")
var E=o("CO+y")
var B=o("6SzX")
var A=o("o/ft")
var S=o("kC3k")
var I=o("JGuX")
const y={ADMIN_LOCKED:{label:w.t("Locked"),icon:A["a"],tooltip:w.t("Unlock"),variant:"primary"},ADMIN_UNLOCKED:{label:w.t("Blueprint"),icon:S["a"],tooltip:w.t("Lock"),variant:"default"},ADMIN_WILLUNLOCK:{label:w.t("Blueprint"),icon:S["a"],tooltip:w.t("Unlock"),variant:"default"},ADMIN_WILLLOCK:{label:w.t("Locked"),icon:A["a"],tooltip:w.t("Lock"),variant:"primary"},TEACH_LOCKED:{label:w.t("Locked"),icon:A["a"]},TEACH_UNLOCKED:{label:w.t("Blueprint"),icon:S["a"]}}
class x extends s["Component"]{static setupRootNode(e,t,o){const c=document.createElement("span")
c.className="bpc-lock-toggle-wrapper"
const l=setInterval(()=>{const a=document.querySelector(e)
if(a){clearInterval(l)
a.insertBefore(c,a.childNodes[t])
o(c)}},200)}constructor(e){super(e)
this.onEnter=()=>{this.props.isToggleable&&this.setState({mode:this.props.isLocked?y.ADMIN_WILLUNLOCK:y.ADMIN_WILLLOCK})}
this.onExit=()=>{this.props.isToggleable&&this.setState({mode:this.props.isLocked?y.ADMIN_LOCKED:y.ADMIN_UNLOCKED})}
this.state={}
this.toggleBtnRef=null
e.isToggleable?this.state.mode=e.isLocked?y.ADMIN_LOCKED:y.ADMIN_UNLOCKED:this.state.mode=e.isLocked?y.TEACH_LOCKED:y.TEACH_UNLOCKED}componentDidMount(){const e=Math.max(...Object.values(y).map(e=>e.label.length))
this.toggleBtnRef&&(this.toggleBtnRef.style.width=.845*e+"em")}render(){var e,t,o,l
const a=this.state.mode.icon
const i=Object(c["a"])("span",{className:"bpc-lock-toggle__label"},void 0,this.state.mode.label||"-")
let n=null
if(this.props.isToggleable){const _=this.state.mode.variant
const r=this.state.mode.tooltip
const s=this.props.isLocked?w.t("Locked. Click to unlock."):w.t("Unlocked. Click to lock.")
n=Object(c["a"])(j["a"],{tip:r,placement:"top",variant:"inverse",on:["hover","focus"]},void 0,this.props.breakpoints.miniTablet?Object(c["a"])(O["a"],{id:"lock-toggle-btn",elementRef:e=>this.toggleBtnRef=e,variant:_,onClick:this.props.onClick,onFocus:this.onEnter,onBlur:this.onExit,onMouseEnter:this.onEnter,onMouseLeave:this.onExit,"aria-pressed":this.props.isLocked},void 0,e||(e=Object(c["a"])(a,{})),t||(t=Object(c["a"])(E["a"],{},void 0,i)),o||(o=Object(c["a"])(B["a"],{},void 0,s))):Object(c["a"])(q["a"],{color:"primary"===_?_:null,onClick:this.props.onClick,onFocus:this.onEnter,onBlur:this.onExit,onMouseEnter:this.onEnter,onMouseLeave:this.onExit,"aria-pressed":this.props.isLocked,screenReaderLabel:s},void 0,l||(l=Object(c["a"])(a,{}))))}else n=Object(c["a"])("span",{className:"bpc__lock-no__toggle"},void 0,Object(c["a"])("span",{className:"bpc__lock-no__toggle-icon"},void 0,Object(c["a"])(a,{})),Object(c["a"])(L["a"],{size:"small"},void 0,i))
return Object(c["a"])("span",{className:"bpc-lock-toggle"},void 0,n)}}x.defaultProps={isToggleable:false,onClick:()=>{},breakpoints:{}}
const M=Object(I["a"])(x)
M.setupRootNode=x.setupRootNode
var R=M
class T{constructor(){this.toggleLocked=()=>{const e=this.props.itemType
const t=this.state,o=t.courseId,c=t.isLocked,l=t.itemId
f["a"].toggleLocked({courseId:o,itemType:e,itemId:l,isLocked:!c}).then(e=>{e.data.success?this.setState({isLocked:!c}):this.showToggleError()}).catch(()=>{this.showToggleError()})}
this.state={isLocked:false,itemLocks:[],isMasterContent:false,isChildContent:false,itemId:""}}init(e){if(!this.shouldInit())return
this.props=g(e)
this.setupState()
void 0!==this.state.itemId&&this.render()}shouldInit(){return ENV.MASTER_COURSE_DATA&&(ENV.MASTER_COURSE_DATA.is_master_course_master_content||ENV.MASTER_COURSE_DATA.is_master_course_child_content)}setupState(){this.state={isLocked:ENV.MASTER_COURSE_DATA.restricted_by_master_course,itemLocks:ENV.MASTER_COURSE_DATA.master_course_restrictions||ENV.MASTER_COURSE_DATA.default_restrictions,isMasterContent:ENV.MASTER_COURSE_DATA.is_master_course_master_content,isChildContent:ENV.MASTER_COURSE_DATA.is_master_course_child_content,courseId:ENV.COURSE_ID,itemId:b()(ENV,this.props.itemIdPath)}}setState(e){this.state=Object.assign(this.state,e)
this.render()}getItemLocks(){return Object(l["a"])({},this.state.itemLocks)}isMasterContent(){return this.state.isMasterContent}isChildContent(){return this.state.isChildContent}showToggleError(){r.a.flashError(n.t("There was a problem toggling the content lock."))}setupToggle(e){if(!this.props.toggleWrapperSelector)return
this.toggleNode?e():R.setupRootNode(this.props.toggleWrapperSelector,this.props.toggleWrapperChildIndex||0,t=>{this.toggleNode=t
e()})}renderLockToggle(){if(!this.props.toggleWrapperSelector)return
this.setupToggle(()=>{u.a.render(Object(c["a"])(R,{isLocked:this.state.isLocked,isToggleable:"show"===this.props.page&&this.state.isMasterContent,onClick:this.toggleLocked}),this.toggleNode)})}renderBanner(){this.bannerNode||(this.bannerNode=C.setupRootNode())
u.a.render(Object(c["a"])(C,{isLocked:this.state.isLocked,itemLocks:this.state.itemLocks}),this.bannerNode)}render(){this.renderBanner()
this.renderLockToggle()}}},JGuX:function(e,t,o){"use strict"
var c=o("An8g")
var l=o("q1tI")
var a=o.n(l)
var i=o("17x9")
var n=o.n(i)
var _=o("7Y4T")
const r={miniTablet:{minWidth:"500px"},tablet:{minWidth:"768px"},desktop:{minWidth:"992px"},desktopNavOpen:{minWidth:"1140px"},desktopOnly:{minWidth:"768px"},mobileOnly:{maxWidth:"767px"}}
const s=e=>{const t={}
e.forEach(e=>t[e]=true)
return t}
const k=e=>t=>window.matchMedia?Object(c["a"])(_["a"],{match:"media",query:r,render:(o,c)=>a.a.createElement(e,Object.assign({breakpoints:s(c)},t))}):a.a.createElement(e,Object.assign({breakpoints:{}},t))
n.a.shape({miniTablet:n.a.bool,tablet:n.a.bool,desktop:n.a.bool,desktopNavOpen:n.a.bool,desktopOnly:n.a.bool,mobileOnly:n.a.bool})
t["a"]=k},L2KU:function(e,t,o){"use strict"
const c=/<(http.*?)>; rel="([a-z]*)"/g
const l=e=>{const t={}
const o=e.headers?e.headers.link:null
if(!o)return t
let l=c.exec(o)
while(l){t[l[2]]=l[1]
l=c.exec(o)}return t}
t["a"]=l},kC3k:function(e,t,o){"use strict"
o.d(t,"a",(function(){return u}))
var c=o("VTBJ")
var l=o("1OyB")
var a=o("vuIU")
var i=o("Ji7U")
var n=o("LK+K")
var _=o("q1tI")
var r=o.n(_)
var s=o("CSQ8")
var k=r.a.createElement("path",{d:"M790.5886,1750.588 L790.5886,1807.059 L847.0586,1807.059 L847.0586,1920 L677.6466,1920 L677.6466,1750.588 L790.5886,1750.588 Z M1208.383,1807.059 L1208.383,1920 L1027.721,1920 L1027.721,1807.059 L1208.383,1807.059 Z M1569.816,1807.059 L1569.816,1920 L1389.154,1920 L1389.154,1807.059 L1569.816,1807.059 Z M1920,1750.588 L1920,1920 L1750.588,1920 L1750.588,1807.059 L1807.059,1807.059 L1807.059,1750.588 L1920,1750.588 Z M1581.1771,338.8238 L1581.1771,564.7058 L1468.2351,564.7058 L1468.2351,451.7648 L451.7651,451.7648 L451.7651,1468.2358 L564.7061,1468.2358 L564.7061,1581.1768 L338.8241,1581.1768 L338.8241,338.8238 L1581.1771,338.8238 Z M1920,1389.265 L1920,1569.927 L1807.059,1569.927 L1807.059,1389.265 L1920,1389.265 Z M790.588,1389.154 L790.588,1569.816 L677.647,1569.816 L677.647,1389.154 L790.588,1389.154 Z M1242.353,0.0004 L1242.353,225.8824 L1129.412,225.8824 L1129.412,112.9414 L112.941,112.9414 L112.941,1129.4124 L225.882,1129.4124 L225.882,1242.3524 L5.68434189e-14,1242.3524 L5.68434189e-14,0.0004 L1242.353,0.0004 Z M1920,1027.831 L1920,1208.492 L1807.059,1208.492 L1807.059,1027.831 L1920,1027.831 Z M790.588,1027.721 L790.588,1208.383 L677.647,1208.383 L677.647,1027.721 L790.588,1027.721 Z M1920,677.6466 L1920,847.0586 L1807.059,847.0586 L1807.059,790.5886 L1750.588,790.5886 L1750.588,677.6466 L1920,677.6466 Z M847.0584,677.6466 L847.0584,790.5886 L790.5884,790.5886 L790.5884,847.0586 L677.6474,847.0586 L677.6474,677.6466 L847.0584,677.6466 Z M1208.492,677.647 L1208.492,790.588 L1027.831,790.588 L1027.831,677.647 L1208.492,677.647 Z M1569.927,677.647 L1569.927,790.588 L1389.265,790.588 L1389.265,677.647 L1569.927,677.647 Z",fillRule:"evenodd",stroke:"none",strokeWidth:"1"})
var u=function(e){Object(i["a"])(o,e)
var t=Object(n["a"])(o)
function o(){Object(l["a"])(this,o)
return t.apply(this,arguments)}Object(a["a"])(o,[{key:"render",value:function(){return r.a.createElement(s["a"],Object.assign({},this.props,{name:"IconBlueprint",viewBox:"0 0 1920 1920"}),k)}}])
o.displayName="IconBlueprintSolid"
return o}(_["Component"])
u.glyphName="blueprint"
u.variant="Solid"
u.propTypes=Object(c["a"])({},s["a"].propTypes)},poaC:function(e,t,o){"use strict"
var c=o("BrAc")
var l=o("L2KU")
var a=o("rf2n")
const i={_depaginate(e,t=Infinity,o=[]){return c["a"].get(e).then(e=>{const c=o.concat(e.data)
const a=t-1
if(e.headers.link&&a>0){const t=Object(l["a"])(e)
if(t.next)return this._depaginate(t.next,a,c)}e.data=c
return e})},_queryString:e=>e.map(e=>{const t=Object.keys(e)[0]
const o=e[t]
return o?`${t}=${o}`:null}).filter(e=>!!e).join("&"),getCourses({accountId:e},{search:t="",term:o="",subAccount:c=""}={}){const l=this._queryString([{per_page:"100"},{blueprint:"false"},{blueprint_associated:"false"},{"include[]":"term"},{"include[]":"teachers"},{teacher_limit:"5"},{search_term:t},{enrollment_term_id:o}])
return this._depaginate(`/api/v1/accounts/${c||e}/courses?${l}`,1)},getAssociations({masterCourse:e}){const t=this._queryString([{per_page:"100"},{teacher_limit:"5"}])
return this._depaginate(`/api/v1/courses/${e.id}/blueprint_templates/default/associated_courses?${t}`)},saveAssociations:({masterCourse:e,addedAssociations:t,removedAssociations:o})=>c["a"].put(`/api/v1/courses/${e.id}/blueprint_templates/default/update_associations`,{course_ids_to_add:t.map(e=>e.id),course_ids_to_remove:o.map(e=>e.id)}),getMigrations:({masterCourse:e})=>c["a"].get(`/api/v1/courses/${e.id}/blueprint_templates/default/migrations`),beginMigration({masterCourse:e,willSendNotification:t,willIncludeCustomNotificationMessage:o,notificationMessage:l,willIncludeCourseSettings:a,willPublishCourses:i}){const n={send_notification:t}
a&&(n.copy_settings=true)
o&&l&&(n.comment=l)
i&&(n.publish_after_initial_sync=true)
return c["a"].post(`/api/v1/courses/${e.id}/blueprint_templates/default/migrations`,n)},checkMigration(e){return this.getMigrations(e).then(e=>{let t=a["a"].void
e.data[0]&&(t=e.data[0].workflow_state)
e.data=t
return e})},getMigration:({course:e},{blueprintType:t="blueprint_templates",templateId:o="default",changeId:l})=>c["a"].get(`/api/v1/courses/${e.id}/${t}/${o}/migrations/${l}`),getMigrationDetails:({course:e},{blueprintType:t="blueprint_templates",templateId:o="default",changeId:l})=>c["a"].get(`/api/v1/courses/${e.id}/${t}/${o}/migrations/${l}/details`),getFullMigration({course:e},t){return this.getMigration({course:e},t).then(({data:o})=>this.getMigrationDetails({course:e},t).then(e=>Object.assign(o,{changeId:t.changeId,changes:e.data})))},getSyncHistory({masterCourse:e}){return this.getMigrations({masterCourse:e}).then(({data:t})=>Promise.all(t.slice(0,5).map(t=>this.getMigrationDetails({course:e},{changeId:t.id}).then(e=>Object.assign(t,{changes:e.data})))))},toggleLocked:({courseId:e,itemType:t,itemId:o,isLocked:l})=>c["a"].put(`/api/v1/courses/${e}/blueprint_templates/default/restrict_item`,{content_type:t,content_id:o,restricted:l}),loadUnsyncedChanges:({masterCourse:e})=>c["a"].get(`/api/v1/courses/${e.id}/blueprint_templates/default/unsynced_changes`)}
t["a"]=i},rf2n:function(e,t,o){"use strict"
const c=["queued","exporting","imports_queued"]
const l=["completed","exports_failed","imports_failed"]
const a=["void","unknown",...c,...l]
const i={statesList:a,states:a.reduce((e,t)=>Object.assign(e,{[t]:t}),{})}
i.isEndState=e=>l.includes(e)
i.isLoadingState=e=>c.includes(e)
i.getLoadingValue=e=>c.indexOf(e)+1
i.isSuccessful=e=>"completed"===e
i.maxLoadingValue=c.length+1
t["a"]=i},tlDv:function(e,t,o){"use strict"
var c=o("17x9")
var l=o.n(c)
var a=o("rf2n")
const i=l.a.shape,n=l.a.string,_=l.a.arrayOf,r=l.a.oneOf,s=l.a.bool,k=l.a.instanceOf
const u={}
u.migrationState=r(a["a"].statesList)
u.term=i({id:n.isRequired,name:n.isRequired})
u.termList=_(u.term)
u.account=i({id:n.isRequired,name:n.isRequired})
u.accountList=_(u.account)
u.course=i({id:n.isRequired,name:n.isRequired,course_code:n.isRequired,term:u.term.isRequired,teachers:_(i({display_name:n.isRequired})),teacher_count:n,sis_course_id:n})
u.courseList=_(u.course)
u.courseInfo=i({id:n.isRequired,name:n.isRequired,enrollment_term_id:n.isRequired,sis_course_id:n})
u.lockableAttribute=r(["points","content","due_dates","availability_dates","settings","deleted"])
u.lockableAttributeList=_(u.lockableAttribute)
u.migrationException=i({course_id:n.isRequired,conflicting_changes:u.lockableAttributeList})
u.migrationExceptionList=_(u.migrationException)
u.migrationChange=i({asset_id:n.isRequired,asset_type:r(["assignment","quiz","discussion_topic","wiki_page","attachment","context_module","learning_outcome","learning_outcome_group","announcement","rubric","syllabus"]).isRequired,asset_name:n.isRequired,change_type:r(["created","updated","deleted"]).isRequired,htnl_url:n,exceptions:u.migrationExceptionList})
u.migrationChangeList=_(u.migrationChange)
u.migration=i({id:n.isRequired,workflow_state:u.migrationState.isRequired,comment:n,created_at:n.isRequired,exports_started_at:n,imports_queued_at:n,imports_completed_at:n,changes:u.migrationChangeList})
u.migrationList=_(u.migration)
u.unsyncedChange=i({asset_id:n.isRequired,asset_type:n.isRequired,asset_name:n.isRequired,change_type:n.isRequired,html_url:n.isRequired,locked:s.isRequired})
u.unsyncedChanges=_(u.unsyncedChange)
u.notification=i({id:n.isRequired,message:n.isRequired,err:k(Error)})
u.notificationList=_(u.notification)
u.itemLocks=i({content:s,points:s,due_dates:s,availability_dates:s})
u.itemLocksByObject=i({assignment:u.itemLocks,discussion_topic:u.itemLocks,wiki_page:u.itemLocks,quiz:u.itemLocks,attachment:u.itemLocks})},wOvH:function(e,t,o){"use strict"
o.d(t,"a",(function(){return _}))
var c=o("HGxv")
var l=o("8WeW")
Object(l["a"])(JSON.parse('{"ar":{"no_attributes_locked_611c5cc":"لم يتم تأمين أي سمات"},"ca":{"no_attributes_locked_611c5cc":"cap atribut bloquejat"},"cy":{"no_attributes_locked_611c5cc":"dim priodoleddau wedi’u cloi"},"da":{"no_attributes_locked_611c5cc":"ingen attributter låst"},"da-x-k12":{"no_attributes_locked_611c5cc":"ingen attributter låst"},"de":{"no_attributes_locked_611c5cc":"Keine Attribute gesperrt"},"en-AU":{"no_attributes_locked_611c5cc":"no attributes locked"},"en-AU-x-unimelb":{"no_attributes_locked_611c5cc":"no attributes locked"},"en-CA":{"no_attributes_locked_611c5cc":"no attributes locked"},"en-GB":{"no_attributes_locked_611c5cc":"no attributes locked"},"en-GB-x-lbs":{"no_attributes_locked_611c5cc":"no attributes locked"},"en-GB-x-ukhe":{"no_attributes_locked_611c5cc":"no attributes locked"},"es":{"no_attributes_locked_611c5cc":"no se han bloqueado atributos"},"fa":{"no_attributes_locked_611c5cc":"هیچ ویژگی قفل نشده"},"fi":{"no_attributes_locked_611c5cc":"ei lukittuja määritteitä"},"fr":{"no_attributes_locked_611c5cc":"aucun attribut verrouillé"},"fr-CA":{"no_attributes_locked_611c5cc":"aucun attribut verrouillé"},"ht":{"no_attributes_locked_611c5cc":"Pa gen okenn atribi ki bloke"},"is":{"no_attributes_locked_611c5cc":"engir læstir eiginleikar"},"it":{"no_attributes_locked_611c5cc":"nessun attributo bloccato"},"ja":{"no_attributes_locked_611c5cc":"属性がロックされていません"},"mi":{"no_attributes_locked_611c5cc":"Kāore ngā huanga i te raka"},"nb":{"no_attributes_locked_611c5cc":"ingen låste attributter"},"nb-x-k12":{"no_attributes_locked_611c5cc":"ingen låste attributter"},"nl":{"no_attributes_locked_611c5cc":"geen vergrendelde eigenschappen"},"nn":{"no_attributes_locked_611c5cc":"ingen attributt er låste"},"pl":{"no_attributes_locked_611c5cc":"brak zablokowanych atrybutów"},"pt":{"no_attributes_locked_611c5cc":"Sem atributos bloqueados"},"pt-BR":{"no_attributes_locked_611c5cc":"nenhum atributo bloqueado"},"ru":{"no_attributes_locked_611c5cc":"нет заблокированных атрибутов"},"sl":{"no_attributes_locked_611c5cc":"ni zaklenjenih atributov"},"sv":{"no_attributes_locked_611c5cc":"inga attribut låsta"},"sv-x-k12":{"no_attributes_locked_611c5cc":"inga attribut låsta"},"uk":{"no_attributes_locked_611c5cc":"немає заблокованих атрибутів"},"zh-Hans":{"no_attributes_locked_611c5cc":"未锁定任何属性"},"zh-Hant":{"no_attributes_locked_611c5cc":"沒有鎖定屬性"}}'))
o("jQeR")
o("0sPK")
var a=c["default"].scoped("blueprint_LockItemFormat")
var i=o("jDZg")
function n(e){const t=e.map(e=>i["e"][e])
switch(t.length){case 0:return a.t("no attributes locked")
case 1:return t[0]
default:return`${t.slice(0,-1).join(", ")} & ${t.slice(-1)[0]}`}}function _(e){const t=Object.keys(e).filter(t=>e[t])
return n(t)}}}])

//# sourceMappingURL=50-c-bebf9aa8b5.js.map