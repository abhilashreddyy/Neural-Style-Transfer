(window["canvasWebpackJsonp"]=window["canvasWebpackJsonp"]||[]).push([[6],{sTNg:function(e,n,t){"use strict"
t.d(n,"a",(function(){return Q}))
t.d(n,"d",(function(){return J}))
t.d(n,"c",(function(){return K}))
t.d(n,"b",(function(){return ae}))
t.d(n,"e",(function(){return u}))
var r=t("1OyB")
var a=t("vuIU")
var i=t("Ji7U")
var o=t("LK+K")
var s=t("q1tI")
var l=t.n(s)
var c=t("17x9")
var d=t.n(c)
var p=t("jtGx")
var u={message:d.a.shape({text:d.a.string,type:d.a.oneOf(["error","hint","success","screenreader-only"])})}
var m=t("VTBJ")
var b=t("rePB")
t("DEX3")
var h=t("TSYQ")
var f=t.n(h)
var g=t("rW8M")
var v=t("6SzX")
var y=t("pZ4s")
var O=t("J2CL")
var j=t("KgFQ")
var k=t("BTe1")
function w(e){var n=e.colors,t=e.typography
return{color:n.textDarkest,fontFamily:t.fontFamily,fontWeight:t.fontWeightBold,fontSize:t.fontSizeMedium,lineHeight:t.lineHeightFit}}w.canvas=function(e){return{color:e["ic-brand-font-color-dark"]}}
var C,x,_,A
var I={componentId:"fCrpb",template:function(e){return"\n\n.fCrpb_bGBk,.fCrpb_bGBk.fCrpb_fVUh,label.fCrpb_bGBk{all:initial;animation:none 0s ease 0s 1 normal none running;backface-visibility:visible;background:transparent none repeat 0 0/auto auto padding-box border-box scroll;border:medium none currentColor;border-collapse:separate;border-image:none;border-radius:0;border-spacing:0;bottom:auto;box-shadow:none;box-sizing:content-box;caption-side:top;clear:none;clip:auto;color:#000;column-count:auto;column-fill:balance;column-gap:normal;column-rule:medium none currentColor;column-span:1;column-width:auto;columns:auto;content:normal;counter-increment:none;counter-reset:none;cursor:auto;direction:ltr;display:inline;display:block;empty-cells:show;float:none;font-family:serif;font-size:medium;font-stretch:normal;font-style:normal;font-variant:normal;font-weight:400;height:auto;hyphens:none;left:auto;letter-spacing:normal;line-height:normal;list-style:disc outside none;margin:0;max-height:none;max-width:none;min-height:0;min-width:0;opacity:1;orphans:2;outline:medium none invert;overflow:visible;overflow-x:visible;overflow-y:visible;padding:0;page-break-after:auto;page-break-before:auto;page-break-inside:auto;perspective:none;perspective-origin:50% 50%;position:static;right:auto;tab-size:8;table-layout:auto;text-align:left;text-align-last:auto;text-decoration:none;text-indent:0;text-shadow:none;text-transform:none;top:auto;transform:none;transform-origin:50% 50% 0;transform-style:flat;transition:none 0s ease 0s;unicode-bidi:normal;vertical-align:baseline;visibility:visible;white-space:normal;widows:2;width:auto;word-spacing:normal;z-index:auto}\n\n.fCrpb_bGBk.fCrpb_fVUh{display:table;width:100%}\n\n.fCrpb_egrg,.fCrpb_egrg.fCrpb_fVUh,label.fCrpb_egrg{color:".concat(e.color||"inherit",";font-family:").concat(e.fontFamily||"inherit",";font-size:").concat(e.fontSize||"inherit",";font-weight:").concat(e.fontWeight||"inherit",";line-height:").concat(e.lineHeight||"inherit",";margin:0;text-align:inherit}\n\n[dir=ltr] .fCrpb_egrg,[dir=ltr] .fCrpb_egrg.fCrpb_fVUh,[dir=ltr] label.fCrpb_egrg,[dir=rtl] .fCrpb_egrg,[dir=rtl] .fCrpb_egrg.fCrpb_fVUh,[dir=rtl] label.fCrpb_egrg{text-align:inherit}")},root:"fCrpb_bGBk",legend:"fCrpb_fVUh","has-content":"fCrpb_egrg"}
var E=(C=Object(O["l"])(w,I),C(x=(A=_=function(e){Object(i["a"])(t,e)
var n=Object(o["a"])(t)
function t(){Object(r["a"])(this,t)
return n.apply(this,arguments)}Object(a["a"])(t,[{key:"render",value:function(){var e
var n=Object(j["a"])(t,this.props)
var r=(e={},Object(b["a"])(e,I.root,true),Object(b["a"])(e,I["has-content"],Object(g["a"])(this.props.children)),e)
return l.a.createElement(n,Object.assign({},Object(p["a"])(this.props,t.propTypes),{className:f()(r)}),this.props.children)}}])
t.displayName="FormFieldLabel"
return t}(s["Component"]),_.propTypes={as:d.a.elementType,children:d.a.node.isRequired},_.defaultProps={as:"span"},A))||x)
function F(e){var n=e.spacing
return{topMargin:n.xxSmall}}function S(e){var n=e.colors,t=e.typography
return{colorHint:n.textDarkest,colorError:n.textDanger,colorSuccess:n.textSuccess,fontFamily:t.fontFamily,fontWeight:t.fontWeightNormal,fontSize:t.fontSizeSmall,lineHeight:t.lineHeight}}S.canvas=function(e){return{colorHint:e["ic-brand-font-color-dark"]}}
var T,B,L,N
var R={componentId:"bVlfD",template:function(e){return"\n\n.bVlfD_bGBk{display:block;font-family:".concat(e.fontFamily||"inherit",";font-size:").concat(e.fontSize||"inherit",";font-weight:").concat(e.fontWeight||"inherit",";line-height:").concat(e.lineHeight||"inherit","}\n\n.bVlfD_dYYb{color:").concat(e.colorHint||"inherit","}\n\n.bVlfD_ddvR{color:").concat(e.colorError||"inherit","}\n\n.bVlfD_cOXX{color:").concat(e.colorSuccess||"inherit","}")},root:"bVlfD_bGBk",hint:"bVlfD_dYYb",error:"bVlfD_ddvR",success:"bVlfD_cOXX"}
var V=(T=Object(O["l"])(S,R),T(B=(N=L=function(e){Object(i["a"])(t,e)
var n=Object(o["a"])(t)
function t(){Object(r["a"])(this,t)
return n.apply(this,arguments)}Object(a["a"])(t,[{key:"render",value:function(){var e
var n=(e={},Object(b["a"])(e,R.root,true),Object(b["a"])(e,R[this.props.variant],true),e)
return"screenreader-only"!==this.props.variant?l.a.createElement("span",{className:f()(n)},this.props.children):l.a.createElement(v["a"],null,this.props.children)}}])
t.displayName="FormFieldMessage"
return t}(s["Component"]),L.propTypes={variant:d.a.oneOf(["error","hint","success","screenreader-only"]),children:d.a.node},L.defaultProps={variant:"hint",children:null},N))||B)
var z,W,G,D
var M={componentId:"fAfJj",template:function(e){return"\n\n.fAfJj_bGBk{margin:calc(-1*".concat(e.topMargin||"inherit",") 0 0 0;padding:0}\n\n.fAfJj_elxg,.fAfJj_bGBk{display:block}")},root:"fAfJj_bGBk",message:"fAfJj_elxg"}
var J=(z=Object(O["l"])(F,M),z(W=(D=G=function(e){Object(i["a"])(t,e)
var n=Object(o["a"])(t)
function t(){Object(r["a"])(this,t)
return n.apply(this,arguments)}Object(a["a"])(t,[{key:"render",value:function(){var e=this.props.messages
return e&&e.length>0?l.a.createElement("span",Object.assign({className:M.root},Object(p["a"])(this.props,t.propTypes)),e.map((function(e,n){return l.a.createElement("span",{key:"error".concat(n),className:M.message},l.a.createElement(V,{variant:e.type},e.text))}))):null}}])
t.displayName="FormFieldMessages"
return t}(s["Component"]),G.propTypes={messages:d.a.arrayOf(u.message)},G.defaultProps={messages:void 0},D))||W)
var X=function(){return{}}
var H,P,U,q
var Y={componentId:"cWmNi",template:function(e){return"\n\n.cWmNi_bGBk{all:initial;animation:none 0s ease 0s 1 normal none running;backface-visibility:visible;background:transparent none repeat 0 0/auto auto padding-box border-box scroll;border:medium none currentColor;border:0;border-collapse:separate;border-image:none;border-radius:0;border-spacing:0;bottom:auto;box-shadow:none;box-sizing:content-box;caption-side:top;clear:none;clip:auto;color:#000;column-count:auto;column-fill:balance;column-gap:normal;column-rule:medium none currentColor;column-span:1;column-width:auto;columns:auto;content:normal;counter-increment:none;counter-reset:none;cursor:auto;direction:ltr;direction:inherit;display:inline;display:block;empty-cells:show;float:none;font-family:serif;font-size:medium;font-stretch:normal;font-style:normal;font-variant:normal;font-weight:400;height:auto;hyphens:none;left:auto;letter-spacing:normal;line-height:normal;list-style:disc outside none;margin:0;max-height:none;max-width:none;min-height:0;min-width:0;opacity:1;opacity:inherit;orphans:2;outline:medium none invert;overflow:visible;overflow-x:visible;overflow-y:visible;padding:0;page-break-after:auto;page-break-before:auto;page-break-inside:auto;perspective:none;perspective-origin:50% 50%;position:static;right:auto;tab-size:8;table-layout:auto;text-align:left;text-align:start;text-align-last:auto;text-decoration:none;text-indent:0;text-shadow:none;text-transform:none;top:auto;transform:none;transform-origin:50% 50% 0;transform-style:flat;transition:none 0s ease 0s;unicode-bidi:normal;vertical-align:baseline;visibility:visible;white-space:normal;widows:2;width:auto;width:100%;word-spacing:normal;z-index:auto}\n\n[dir=ltr] .cWmNi_bGBk{text-align:left}\n\n[dir=rtl] .cWmNi_bGBk{text-align:right}\n\n.cWmNi_eXrk{display:inline-block;vertical-align:middle;width:auto}"},root:"cWmNi_bGBk",inline:"cWmNi_eXrk"}
var K=(H=Object(O["l"])(X,Y),H(P=(q=U=function(e){Object(i["a"])(t,e)
var n=Object(o["a"])(t)
function t(e){var a
Object(r["a"])(this,t)
a=n.call(this)
a.handleInputContainerRef=function(e){a.props.inputContainerRef&&a.props.inputContainerRef(e)}
a._messagesId=e.messagesId||Object(k["a"])("FormFieldLayout-messages")
"undefined"!==typeof e.width||!e.inline||e.layout
return a}Object(a["a"])(t,[{key:"renderLabel",value:function(){return this.hasVisibleLabel?l.a.createElement(y["a"].Col,{textAlign:this.props.labelAlign,width:this.inlineContainerAndLabel?"auto":3},l.a.createElement(E,{"aria-hidden":"fieldset"===this.elementType?"true":null},this.props.label)):"fieldset"!==this.elementType?this.props.label:null}},{key:"renderLegend",value:function(){return l.a.createElement(v["a"],{as:"legend"},this.props.label,this.hasMessages&&l.a.createElement(J,{messages:this.props.messages}))}},{key:"renderMessages",value:function(){return l.a.createElement(J,{id:this._messagesId,messages:this.props.messages})}},{key:"renderVisibleMessages",value:function(){return this.hasMessages?l.a.createElement(y["a"].Row,null,l.a.createElement(y["a"].Col,{offset:this.inlineContainerAndLabel?null:3,textAlign:this.inlineContainerAndLabel?"end":null},l.a.createElement(J,{id:this._messagesId,messages:this.props.messages}))):null}},{key:"render",value:function(){var e
var n=this.elementType
var r=(e={},Object(b["a"])(e,Y.root,true),Object(b["a"])(e,Y.inline,this.props.inline),e)
return l.a.createElement(n,Object.assign({},Object(p["a"])(this.props,Object(m["a"])({},t.propTypes,{},y["a"].propTypes)),{className:f()(r),style:{width:this.props.width},"aria-describedby":this.hasMessages?this._messagesId:null}),"fieldset"===this.elementType&&this.renderLegend(),l.a.createElement(y["a"],Object.assign({rowSpacing:"small",colSpacing:"small",startAt:"inline"===this.props.layout&&this.hasVisibleLabel?"medium":null},Object(p["c"])(this.props,y["a"].propTypes)),l.a.createElement(y["a"].Row,null,this.renderLabel(),l.a.createElement(y["a"].Col,{width:this.inlineContainerAndLabel?"auto":null,elementRef:this.handleInputContainerRef},this.props.children)),this.renderVisibleMessages()))}},{key:"hasVisibleLabel",get:function(){return this.props.label&&Object(g["a"])(this.props.label)}},{key:"hasMessages",get:function(){return this.props.messages&&this.props.messages.length>0}},{key:"elementType",get:function(){return Object(j["a"])(t,this.props)}},{key:"inlineContainerAndLabel",get:function(){return this.props.inline&&"inline"===this.props.layout}}])
t.displayName="FormFieldLayout"
return t}(s["Component"]),U.propTypes={label:d.a.node.isRequired,id:d.a.string,as:d.a.elementType,messages:d.a.arrayOf(u.message),messagesId:d.a.string,children:d.a.node,inline:d.a.bool,layout:d.a.oneOf(["stacked","inline"]),labelAlign:d.a.oneOf(["start","end"]),width:d.a.string,inputContainerRef:d.a.func},U.defaultProps={id:void 0,width:void 0,messages:void 0,messagesId:void 0,children:null,inline:false,layout:"stacked",as:"label",labelAlign:"end",inputContainerRef:void 0},q))||P)
var Q=function(e){Object(i["a"])(t,e)
var n=Object(o["a"])(t)
function t(){Object(r["a"])(this,t)
return n.apply(this,arguments)}Object(a["a"])(t,[{key:"render",value:function(){return l.a.createElement(K,Object.assign({},Object(p["a"])(this.props,t.propTypes),Object(p["c"])(this.props,K.propTypes),{vAlign:this.props.vAlign,as:"label",htmlFor:this.props.id}))}}])
t.displayName="FormField"
return t}(s["Component"])
Q.propTypes={label:d.a.node.isRequired,id:d.a.string.isRequired,messages:d.a.arrayOf(u.message),messagesId:d.a.string,children:d.a.node,inline:d.a.bool,layout:d.a.oneOf(["stacked","inline"]),labelAlign:d.a.oneOf(["start","end"]),vAlign:d.a.oneOf(["top","middle","bottom"]),width:d.a.string,inputContainerRef:d.a.func}
Q.defaultProps={inline:false,layout:"stacked",labelAlign:"end",vAlign:"middle",messages:void 0,messagesId:void 0,children:null,width:void 0,inputContainerRef:void 0}
var Z=function(e){var n=e.borders,t=e.colors,r=e.spacing
return{borderWidth:n.widthSmall,borderStyle:n.style,borderColor:"transparent",borderRadius:n.radiusMedium,errorBorderColor:t.borderDanger,errorFieldsPadding:r.xSmall}}
var $,ee,ne,te
var re={componentId:"efIdg",template:function(e){return"\n\n.efIdg_cLpc{border:".concat(e.borderWidth||"inherit"," ").concat(e.borderStyle||"inherit"," ").concat(e.borderColor||"inherit",";border-radius:").concat(e.borderRadius||"inherit",";display:block}\n\n.efIdg_cLpc.efIdg_fszt{border-color:").concat(e.errorBorderColor||"inherit",";padding:").concat(e.errorFieldsPadding||"inherit","}\n\n.efIdg_cLpc.efIdg_ywdX{cursor:not-allowed;opacity:0.6;pointer-events:none}")},fields:"efIdg_cLpc",invalid:"efIdg_fszt",disabled:"efIdg_ywdX"}
var ae=($=Object(O["l"])(Z,re),$(ee=(te=ne=function(e){Object(i["a"])(t,e)
var n=Object(o["a"])(t)
function t(){Object(r["a"])(this,t)
return n.apply(this,arguments)}Object(a["a"])(t,[{key:"renderColumns",value:function(){return s["Children"].map(this.props.children,(function(e,n){return e?l.a.createElement(y["a"].Col,{width:e.props&&e.props.width?"auto":null,key:n},e):null}))}},{key:"renderChildren",value:function(){return l.a.createElement(y["a"],{colSpacing:this.props.colSpacing,rowSpacing:this.props.rowSpacing,vAlign:this.props.vAlign,startAt:this.props.startAt||("columns"===this.props.layout?"medium":null)},l.a.createElement(y["a"].Row,null,this.renderColumns()))}},{key:"renderFields",value:function(){var e
return l.a.createElement("span",{key:"fields",className:f()((e={},Object(b["a"])(e,re.fields,true),Object(b["a"])(e,re.invalid,this.invalid),Object(b["a"])(e,re.disabled,this.props.disabled),e))},this.renderChildren())}},{key:"render",value:function(){return l.a.createElement(K,Object.assign({},Object(p["a"])(this.props,t.propTypes),Object(p["c"])(this.props,K.propTypes),{vAlign:this.props.vAlign,layout:"inline"===this.props.layout?"inline":"stacked",label:this.props.description,"aria-disabled":this.props.disabled?"true":null,"aria-invalid":this.invalid?"true":null}),this.renderFields())}},{key:"invalid",get:function(){return this.props.messages&&this.props.messages.findIndex((function(e){return"error"===e.type}))>=0}}])
t.displayName="FormFieldGroup"
return t}(s["Component"]),ne.propTypes={description:d.a.node.isRequired,as:d.a.elementType,messages:d.a.arrayOf(u.message),messagesId:d.a.string,disabled:d.a.bool,children:d.a.node,layout:d.a.oneOf(["stacked","columns","inline"]),rowSpacing:d.a.oneOf(["none","small","medium","large"]),colSpacing:d.a.oneOf(["none","small","medium","large"]),vAlign:d.a.oneOf(["top","middle","bottom"]),startAt:d.a.oneOf(["small","medium","large","x-large",null])},ne.defaultProps={children:null,layout:void 0,startAt:void 0,messages:void 0,messagesId:void 0,as:"fieldset",disabled:false,rowSpacing:"medium",colSpacing:"small",vAlign:"middle"},te))||ee)}}])

//# sourceMappingURL=6-c-b5dbcf1cf8.js.map