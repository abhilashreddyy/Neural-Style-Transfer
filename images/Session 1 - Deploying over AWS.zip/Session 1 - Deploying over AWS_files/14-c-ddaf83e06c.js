(window["canvasWebpackJsonp"]=window["canvasWebpackJsonp"]||[]).push([[14],{"9lnB":function(e,n,t){"use strict"
t.d(n,"a",(function(){return G}))
var a=t("rePB")
var r=t("1OyB")
var o=t("vuIU")
var i=t("Ji7U")
var c=t("LK+K")
t("DEX3")
var l=t("q1tI")
var d=t.n(l)
var s=t("17x9")
var h=t.n(s)
var u=t("3zPy")
var f=t.n(u)
var b=t("TSYQ")
var m=t.n(b)
var y=t("cClk")
var p=t("sTNg")
var g=t("9yTY")
var v=t("BTe1")
var k=t("/UXv")
var _=t("J2CL")
var S=t("jtGx")
var W=t("oXx0")
var J=t("hPGw")
var O=t("VTBJ")
var z=d.a.createElement("path",{d:"M1743.8579 267.012456L710.746654 1300.1237 176.005086 765.382131 0 941.387217 710.746654 1652.25843 1919.98754 443.142104z",fillRule:"evenodd",stroke:"none",strokeWidth:"1"})
var j=function(e){Object(i["a"])(t,e)
var n=Object(c["a"])(t)
function t(){Object(r["a"])(this,t)
return n.apply(this,arguments)}Object(o["a"])(t,[{key:"render",value:function(){return d.a.createElement(J["a"],Object.assign({},this.props,{name:"IconCheckMark",viewBox:"0 0 1920 1920"}),z)}}])
t.displayName="IconCheckMarkSolid"
return t}(l["Component"])
j.glyphName="check-mark"
j.variant="Solid"
j.propTypes=Object(O["a"])({},J["a"].propTypes)
function w(e){var n=e.colors,t=e.borders,a=e.spacing,r=e.typography
return{color:n.textLightest,borderWidth:t.widthSmall,borderColor:n.borderDark,borderRadius:t.radiusMedium,background:n.backgroundLightest,marginRight:a.xSmall,padding:a.xxxSmall,checkedBackground:n.backgroundDarkest,checkedBorderColor:n.borderDarkest,hoverBorderColor:n.borderDarkest,focusBorderColor:n.borderBrand,focusBorderWidth:t.widthMedium,focusBorderStyle:t.style,labelColor:n.textDarkest,checkedLabelColor:n.textDarkest,labelFontFamily:r.fontFamily,labelFontWeight:r.fontWeightNormal,labelLineHeight:r.lineHeightCondensed,facadeSizeSmall:"1rem",facadeSizeMedium:"1.25rem",facadeSizeLarge:"1.75rem",labelFontSizeSmall:r.fontSizeSmall,labelFontSizeMedium:r.fontSizeMedium,labelFontSizeLarge:r.fontSizeLarge,iconSizeSmall:"0.625rem",iconSizeMedium:"0.75rem",iconSizeLarge:"1rem"}}w.canvas=function(e){return{focusBorderColor:e["ic-brand-primary"],labelColor:e["ic-brand-font-color-dark"],checkedLabelColor:e["ic-brand-font-color-dark"],checkedBackground:e["ic-brand-font-color-dark"],checkedBorderColor:e["ic-brand-font-color-dark"],hoverBorderColor:e["ic-brand-font-color-dark"]}}
var x,C,B,M
var P={componentId:"yyQPt",template:function(e){return"\n\n.yyQPt_bGBk{align-items:flex-start;display:flex}\n\n.yyQPt_cSXm{-webkit-margin-end:".concat(e.marginRight||"inherit",";-webkit-margin-start:0;align-items:center;background:").concat(e.background||"inherit",";border:").concat(e.borderWidth||"inherit"," solid ").concat(e.borderColor||"inherit",";border-radius:").concat(e.borderRadius||"inherit",";box-sizing:border-box;color:").concat(e.color||"inherit",";display:flex;flex-shrink:0;justify-content:center;margin-inline-end:").concat(e.marginRight||"inherit",";margin-inline-start:0;padding:").concat(e.padding||"inherit",";position:relative;transition:all 0.2s}\n\n[dir=ltr] .yyQPt_cSXm{margin-left:0;margin-right:").concat(e.marginRight||"inherit","}\n\n[dir=rtl] .yyQPt_cSXm{margin-left:").concat(e.marginRight||"inherit",";margin-right:0}\n\n.yyQPt_cSXm:before{border:").concat(e.focusBorderWidth||"inherit"," ").concat(e.focusBorderStyle||"inherit"," ").concat(e.focusBorderColor||"inherit",";border-radius:calc(").concat(e.borderRadius||"inherit",'*1.5);bottom:-0.3125rem;box-sizing:border-box;content:"";left:-0.3125rem;opacity:0;pointer-events:none;position:absolute;right:-0.3125rem;top:-0.3125rem;transform:scale(0.75);transition:all 0.2s}\n\n.yyQPt_blJt{color:').concat(e.labelColor||"inherit",";flex:1 1 auto;font-family:").concat(e.labelFontFamily||"inherit",";font-weight:").concat(e.labelFontWeight||"inherit",";line-height:").concat(e.labelLineHeight||"inherit",";min-width:0.0625rem}\n\n.yyQPt_doqw .yyQPt_blJt{font-size:").concat(e.labelFontSizeSmall||"inherit","}\n\n.yyQPt_doqw .yyQPt_cSXm{font-size:").concat(e.iconSizeSmall||"inherit",";height:").concat(e.facadeSizeSmall||"inherit",";width:").concat(e.facadeSizeSmall||"inherit","}\n\n.yyQPt_ycrn .yyQPt_blJt{font-size:").concat(e.labelFontSizeMedium||"inherit","}\n\n.yyQPt_ycrn .yyQPt_cSXm{font-size:").concat(e.iconSizeMedium||"inherit",";height:").concat(e.facadeSizeMedium||"inherit",";width:").concat(e.facadeSizeMedium||"inherit","}\n\n.yyQPt_cMDj .yyQPt_blJt{font-size:").concat(e.labelFontSizeLarge||"inherit","}\n\n.yyQPt_cMDj .yyQPt_cSXm{font-size:").concat(e.iconSizeLarge||"inherit",";height:").concat(e.facadeSizeLarge||"inherit",";width:").concat(e.facadeSizeLarge||"inherit","}\n\n.yyQPt_cjfS .yyQPt_cSXm{background:").concat(e.checkedBackground||"inherit",";border-color:").concat(e.checkedBorderColor||"inherit","}\n\n.yyQPt_cjfS .yyQPt_blJt{color:").concat(e.checkedLabelColor||"inherit","}\n\n.yyQPt_cVYB .yyQPt_cSXm:before{opacity:1;transform:scale(1)}\n\n.yyQPt_Ffcq .yyQPt_cSXm{border-color:").concat(e.hoverBorderColor||"inherit","}")},root:"yyQPt_bGBk",facade:"yyQPt_cSXm",label:"yyQPt_blJt",small:"yyQPt_doqw",medium:"yyQPt_ycrn",large:"yyQPt_cMDj",checked:"yyQPt_cjfS",focused:"yyQPt_cVYB",hovered:"yyQPt_Ffcq"}
var X=d.a.createElement(J["a"],{viewBox:"0 0 1920 1920",inline:false},d.a.createElement("rect",{x:"140",y:"820",width:"1640",height:"280"}))
var Q=d.a.createElement(j,{inline:false})
var F=(x=Object(_["l"])(w,P),x(C=(M=B=function(e){Object(i["a"])(t,e)
var n=Object(c["a"])(t)
function t(){Object(r["a"])(this,t)
return n.apply(this,arguments)}Object(o["a"])(t,[{key:"renderIcon",value:function(){return this.props.indeterminate?X:this.props.checked?Q:null}},{key:"render",value:function(){var e
var n=this.props,t=n.size,r=n.checked,o=n.focused,i=n.hovered,c=n.indeterminate
var l=(e={},Object(a["a"])(e,P.root,true),Object(a["a"])(e,P.checked,r||c),Object(a["a"])(e,P.focused,o),Object(a["a"])(e,P.hovered,i),Object(a["a"])(e,P[t],true),e)
return d.a.createElement("span",{className:m()(l)},d.a.createElement("span",{className:P.facade,"aria-hidden":"true"},this.renderIcon()),d.a.createElement("span",{className:P.label},this.props.children))}}])
t.displayName="CheckboxFacade"
return t}(l["Component"]),B.propTypes={children:h.a.node.isRequired,checked:h.a.bool,focused:h.a.bool,hovered:h.a.bool,size:h.a.oneOf(["small","medium","large"]),indeterminate:h.a.bool},B.defaultProps={checked:false,focused:false,hovered:false,size:"medium",indeterminate:false},M))||C)
var L=t("EQyN")
var E=function(){return{}}
var R,D,N,I,V
var T={componentId:"epRMX",template:function(e){return"\n\n.epRMX_bGBk{position:relative;width:100%}\n\n.epRMX_bOnW{all:initial;animation:none 0s ease 0s 1 normal none running;backface-visibility:visible;background:transparent none repeat 0 0/auto auto padding-box border-box scroll;border:medium none currentColor;border-collapse:separate;border-image:none;border-radius:0;border-spacing:0;bottom:auto;box-shadow:none;box-sizing:content-box;caption-side:top;clear:none;clip:auto;color:#000;column-count:auto;column-fill:balance;column-gap:normal;column-rule:medium none currentColor;column-span:1;column-width:auto;columns:auto;content:normal;counter-increment:none;counter-reset:none;cursor:auto;direction:ltr;direction:inherit;display:inline;display:block;empty-cells:show;float:none;font-family:serif;font-size:medium;font-stretch:normal;font-style:normal;font-variant:normal;font-weight:400;height:auto;hyphens:none;left:auto;letter-spacing:normal;line-height:normal;list-style:disc outside none;margin:0;max-height:none;max-width:none;min-height:0;min-width:0;opacity:1;orphans:2;outline:medium none invert;overflow:visible;overflow-x:visible;overflow-y:visible;padding:0;page-break-after:auto;page-break-before:auto;page-break-inside:auto;perspective:none;perspective-origin:50% 50%;position:static;right:auto;tab-size:8;table-layout:auto;text-align:left;text-align:start;text-align-last:auto;text-decoration:none;text-indent:0;text-shadow:none;text-transform:none;top:auto;transform:none;transform-origin:50% 50% 0;transform-style:flat;transition:none 0s ease 0s;unicode-bidi:normal;vertical-align:baseline;visibility:visible;white-space:normal;widows:2;width:auto;word-spacing:normal;z-index:auto}\n\n[dir=ltr] .epRMX_bOnW{text-align:left}\n\n[dir=rtl] .epRMX_bOnW{text-align:right}\n\n.epRMX_cwos{font-size:inherit;inset-inline-end:auto;inset-inline-start:0;line-height:inherit;margin:0;opacity:0.0001;padding:0;position:absolute;top:0;width:auto}\n\n[dir=ltr] .epRMX_cwos{left:0;right:auto}\n\n[dir=rtl] .epRMX_cwos{left:auto;right:0}\n\n.epRMX_ywdX{cursor:not-allowed;opacity:0.5;pointer-events:none}\n\n.epRMX_eXrk{display:inline-block;vertical-align:middle;width:auto}"},root:"epRMX_bGBk",control:"epRMX_bOnW",input:"epRMX_cwos",disabled:"epRMX_ywdX",inline:"epRMX_eXrk"}
var G=(R=Object(W["a"])(),D=Object(_["l"])(E,T),R(N=D(N=(V=I=function(e){Object(i["a"])(t,e)
var n=Object(c["a"])(t)
function t(e){var a
Object(r["a"])(this,t)
a=n.call(this,e)
a.handleChange=function(e){var n=a.props,t=n.onChange,r=n.disabled,o=n.checked,i=n.readOnly
if(r||i){e.preventDefault()
return}"undefined"===typeof o&&a.setState({checked:!a.state.checked})
"function"===typeof t&&t(e)}
a.handleKeyDown=function(e){if("toggle"===a.props.variant&&(e.keyCode===f.a.codes.enter||e.keyCode===f.a.codes.return)){a._input.click()
e.preventDefault()}}
a.handleFocus=function(e){a.setState({focused:true})}
a.handleBlur=function(e){a.setState({focused:false})}
a.handleMouseOver=function(e){a.setState({hovered:true})}
a.handleMouseOut=function(e){a.setState({hovered:false})}
a.state={focused:false,hovered:false}
"undefined"===typeof e.checked&&(a.state.checked=!!e.defaultChecked)
a._defaultId=Object(v["a"])("Checkbox")
return a}Object(o["a"])(t,[{key:"componentDidMount",value:function(){this._input.indeterminate=this.props.indeterminate}},{key:"componentDidUpdate",value:function(e){e.indeterminate!==this.props.indeterminate&&(this._input.indeterminate=this.props.indeterminate)}},{key:"focus",value:function(){this._input&&this._input.focus()}},{key:"renderFacade",value:function(){var e=this.props,n=e.size,t=e.disabled,a=e.variant,r=e.label,o=e.readOnly,i=e.indeterminate,c=e.labelPlacement
var l=this.state,s=l.hovered,h=l.focused
return"toggle"===a?d.a.createElement(L["a"],{disabled:t,size:n,hovered:s,focused:h,checked:this.checked,readOnly:o,labelPlacement:c},r):d.a.createElement(F,{size:n,hovered:s,focused:h,checked:this.checked,indeterminate:i},r)}},{key:"render",value:function(){var e,n=this
var r=this.props,o=r.inline,i=r.disabled,c=r.readOnly,l=r.messages,s=r.value,h=r.onKeyDown,u=r.onFocus,f=r.onBlur,b=r.onMouseOver,y=r.onMouseOut,v=r.indeterminate
r.variant
var k=Object(S["a"])(this.props,t.propTypes)
var _=(e={},Object(a["a"])(e,T.root,true),Object(a["a"])(e,T.disabled,i),Object(a["a"])(e,T.inline,o),e)
return d.a.createElement("div",{className:m()(_),onMouseOver:Object(g["a"])(b,this.handleMouseOver),onMouseOut:Object(g["a"])(y,this.handleMouseOut)},d.a.createElement("input",Object.assign({},k,{id:this.id,value:s,type:"checkbox",ref:function(e){n._input=e},disabled:i||c,"aria-checked":v?"mixed":null,className:T.input,onChange:this.handleChange,onKeyDown:Object(g["a"])(h,this.handleKeyDown),onFocus:Object(g["a"])(u,this.handleFocus),onBlur:Object(g["a"])(f,this.handleBlur),checked:this.checked})),d.a.createElement("label",{htmlFor:this.id,className:T.control},this.renderFacade(),d.a.createElement(p["d"],{messages:l})))}},{key:"id",get:function(){return this.props.id||this._defaultId}},{key:"checked",get:function(){return"undefined"===typeof this.props.checked?this.state.checked:this.props.checked}},{key:"focused",get:function(){return Object(k["a"])(this._input)}}])
t.displayName="Checkbox"
return t}(l["Component"]),I.propTypes={label:h.a.node.isRequired,id:h.a.string,value:h.a.oneOfType([h.a.string,h.a.number]),messages:h.a.arrayOf(p["e"].message),defaultChecked:h.a.bool,checked:Object(y["a"])(h.a.bool,"onChange","defaultChecked"),onChange:h.a.func,onKeyDown:h.a.func,onFocus:h.a.func,onBlur:h.a.func,onMouseOver:h.a.func,onMouseOut:h.a.func,disabled:h.a.bool,readOnly:h.a.bool,indeterminate:h.a.bool,size:h.a.oneOf(["small","medium","large"]),variant:h.a.oneOf(["simple","toggle"]),inline:h.a.bool,labelPlacement:h.a.oneOf(["top","start","end"])},I.defaultProps={size:"medium",variant:"simple",disabled:false,inline:false,indeterminate:false,readOnly:false,onChange:void 0,onKeyDown:void 0,onFocus:void 0,onBlur:void 0,onMouseOut:void 0,onMouseOver:void 0,checked:void 0,defaultChecked:void 0,messages:void 0,id:void 0,value:void 0,labelPlacement:"end"},V))||N)||N)},EQyN:function(e,n,t){"use strict"
t.d(n,"a",(function(){return x}))
var a=t("rePB")
var r=t("1OyB")
var o=t("vuIU")
var i=t("Ji7U")
var c=t("LK+K")
var l=t("q1tI")
var d=t.n(l)
var s=t("17x9")
var h=t.n(s)
var u=t("TSYQ")
var f=t.n(u)
var b=t("VTBJ")
var m=t("hPGw")
var y=d.a.createElement("path",{d:"M1743.8579 267.012456L710.746654 1300.1237 176.005086 765.382131 0 941.387217 710.746654 1652.25843 1919.98754 443.142104z",fillRule:"evenodd",stroke:"none",strokeWidth:"1"})
var p=function(e){Object(i["a"])(t,e)
var n=Object(c["a"])(t)
function t(){Object(r["a"])(this,t)
return n.apply(this,arguments)}Object(o["a"])(t,[{key:"render",value:function(){return d.a.createElement(m["a"],Object.assign({},this.props,{name:"IconCheck",viewBox:"0 0 1920 1920"}),y)}}])
t.displayName="IconCheckSolid"
return t}(l["Component"])
p.glyphName="check"
p.variant="Solid"
p.propTypes=Object(b["a"])({},m["a"].propTypes)
var g=d.a.createElement("path",{d:"M797.319865 985.881673L344.771525 1438.43001 533.333333 1626.99182 985.881673 1174.44348 1438.43001 1626.99182 1626.99182 1438.43001 1174.44348 985.881673 1626.99182 533.333333 1438.43001 344.771525 985.881673 797.319865 533.333333 344.771525 344.771525 533.333333z",fillRule:"nonzero",stroke:"none",strokeWidth:"1"})
var v=function(e){Object(i["a"])(t,e)
var n=Object(c["a"])(t)
function t(){Object(r["a"])(this,t)
return n.apply(this,arguments)}Object(o["a"])(t,[{key:"render",value:function(){return d.a.createElement(m["a"],Object.assign({},this.props,{name:"IconX",viewBox:"0 0 1920 1920"}),g)}}])
t.displayName="IconXSolid"
return t}(l["Component"])
v.glyphName="x"
v.variant="Solid"
v.propTypes=Object(b["a"])({},m["a"].propTypes)
var k=t("J2CL")
function _(e){var n=e.colors,t=e.borders,a=e.forms,r=e.shadows,o=e.spacing,i=e.typography
return{color:n.textLightest,background:n.backgroundLight,borderColor:n.borderMedium,borderWidth:t.widthMedium,borderRadius:"4rem",marginEnd:o.small,marginStart:o.small,marginVertical:o.xSmall,checkedBackground:n.backgroundSuccess,uncheckedIconColor:n.textDarkest,checkedIconColor:n.textSuccess,focusOutlineColor:n.borderBrand,focusBorderWidth:t.widthMedium,focusBorderStyle:t.style,toggleBackground:n.backgroundLightest,toggleShadow:r.depth1,toggleSize:a.inputHeightSmall,labelColor:n.textDarkest,labelFontFamily:i.fontFamily,labelFontWeight:i.fontWeightNormal,labelLineHeight:i.lineHeightCondensed,labelFontSizeSmall:i.fontSizeSmall,labelFontSizeMedium:i.fontSizeMedium,labelFontSizeLarge:i.fontSizeLarge}}_["canvas-a11y"]=_["canvas-high-contrast"]=function(e){var n=e.colors
return{background:n.backgroundDarkest,borderColor:n.borderDarkest}}
_.canvas=function(e){return{focusOutlineColor:e["ic-brand-primary"],labelColor:e["ic-brand-font-color-dark"]}}
var S={baseSizeSmall:"toggleSize",baseSizeMedium:"toggleSize",baseSizeLarge:"toggleSize"}
var W=Object(k["e"])({map:S,version:"8.0.0"})
var J,O,z,j
var w={componentId:"faJyW",template:function(e){return"\n\n.faJyW_bGBk{align-items:center;display:flex}\n\n.faJyW_bGBk.faJyW_dacV{display:block}\n\n.faJyW_bGBk .faJyW_cSXm.faJyW_cjfS{background:".concat(e.checkedBackground||"inherit",";box-shadow:none}\n\n.faJyW_bGBk .faJyW_cSXm.faJyW_cjfS .faJyW_dnnz{transform:translate3d(50%,0,0)}\n\n.faJyW_bGBk .faJyW_cSXm.faJyW_cjfS .faJyW_eoCh{color:").concat(e.checkedIconColor||"inherit","}\n\n.faJyW_bGBk .faJyW_cSXm.faJyW_cVYB:before{opacity:1;transform:scale(1)}\n\n[dir=rtl] .faJyW_bGBk .faJyW_cSXm.faJyW_cjfS .faJyW_dnnz{transform:translate3d(-50%,0,0)}\n\n.faJyW_cSXm.faJyW_dxfV{-webkit-margin-end:0;-webkit-margin-start:").concat(e.marginStart||"inherit",";margin-inline-end:0;margin-inline-start:").concat(e.marginStart||"inherit","}\n\n[dir=ltr] .faJyW_cSXm.faJyW_dxfV{margin-left:").concat(e.marginStart||"inherit",";margin-right:0}\n\n[dir=rtl] .faJyW_cSXm.faJyW_dxfV{margin-left:0;margin-right:").concat(e.marginStart||"inherit","}\n\n.faJyW_cSXm.faJyW_bYta{-webkit-margin-end:").concat(e.marginEnd||"inherit",";-webkit-margin-start:0;margin-inline-end:").concat(e.marginEnd||"inherit",";margin-inline-start:0}\n\n[dir=ltr] .faJyW_cSXm.faJyW_bYta{margin-left:0;margin-right:").concat(e.marginEnd||"inherit","}\n\n[dir=rtl] .faJyW_cSXm.faJyW_bYta{margin-left:").concat(e.marginEnd||"inherit",";margin-right:0}\n\n.faJyW_cSXm.faJyW_dacV{margin-top:").concat(e.marginVertical||"inherit","}\n\n.faJyW_cSXm{-ms-user-select:none;-webkit-user-select:none;background:").concat(e.background||"inherit",";border-color:").concat(e.borderColor||"inherit",";border-radius:3rem;box-shadow:inset 0 0 0 ").concat(e.borderWidth||"inherit"," ").concat(e.borderColor||"inherit",";cursor:pointer;display:inline-block;position:relative;user-select:none;vertical-align:middle}\n\n.faJyW_cSXm:before{border:").concat(e.focusBorderWidth||"inherit"," ").concat(e.focusBorderStyle||"inherit"," ").concat(e.focusOutlineColor||"inherit",";border-radius:").concat(e.borderRadius||"inherit",';box-sizing:border-box;content:"";height:calc(100% + 0.5rem);left:-0.25rem;opacity:0;pointer-events:none;top:-0.25rem;transform:scale(0.75);width:calc(100% + 0.5rem)}\n\n.faJyW_cSXm:before,.faJyW_dnnz{position:absolute;transition:all 0.2s}\n\n.faJyW_dnnz{display:block;inset-inline-end:auto;inset-inline-start:0;text-align:center;top:0;transform:translateZ(0)}\n\n[dir=ltr] .faJyW_dnnz{left:0;right:auto;text-align:center}\n\n[dir=rtl] .faJyW_dnnz{left:auto;right:0;text-align:center}\n\n.faJyW_cMpH{align-items:center;display:flex;height:100%;justify-content:center;position:relative;width:100%}\n\n.faJyW_cMpH:before{background:').concat(e.toggleBackground||"inherit",";border-radius:100%;box-shadow:").concat(e.toggleShadow||"inherit",';content:"";height:calc(100% - ').concat(e.borderWidth||"inherit","*2);left:").concat(e.borderWidth||"inherit",";position:absolute;top:").concat(e.borderWidth||"inherit",";width:calc(100% - ").concat(e.borderWidth||"inherit","*2)}\n\n.faJyW_eoCh{color:").concat(e.uncheckedIconColor||"inherit",";display:block;position:relative;z-index:1}\n\n.faJyW_blJt{color:").concat(e.labelColor||"inherit",";flex:1;font-family:").concat(e.labelFontFamily||"inherit",";font-weight:").concat(e.labelFontWeight||"inherit",";line-height:").concat(e.labelLineHeight||"inherit",";min-width:0.0625rem}\n\n.faJyW_blJt.faJyW_dxfV{text-align:end}\n\n[dir=ltr] .faJyW_blJt.faJyW_dxfV{text-align:right}\n\n[dir=rtl] .faJyW_blJt.faJyW_dxfV{text-align:left}\n\n.faJyW_blJt.faJyW_dacV{display:block}\n\n.faJyW_cMDj,.faJyW_ycrn,.faJyW_doqw{height:").concat(e.toggleSize||"inherit",";width:calc(").concat(e.toggleSize||"inherit","*1.5)}\n\n.faJyW_cMDj .faJyW_dnnz,.faJyW_ycrn .faJyW_dnnz,.faJyW_doqw .faJyW_dnnz{font-size:0.875rem;height:").concat(e.toggleSize||"inherit",";width:").concat(e.toggleSize||"inherit","}\n\n.faJyW_doqw+.faJyW_blJt{font-size:").concat(e.labelFontSizeSmall||"inherit","}\n\n.faJyW_ycrn+.faJyW_blJt{font-size:").concat(e.labelFontSizeMedium||"inherit","}\n\n.faJyW_cMDj+.faJyW_blJt{font-size:").concat(e.labelFontSizeLarge||"inherit","}")},root:"faJyW_bGBk",top:"faJyW_dacV",facade:"faJyW_cSXm",checked:"faJyW_cjfS",icon:"faJyW_dnnz",iconSVG:"faJyW_eoCh",focused:"faJyW_cVYB",start:"faJyW_dxfV",end:"faJyW_bYta",iconToggle:"faJyW_cMpH",label:"faJyW_blJt",large:"faJyW_cMDj",medium:"faJyW_ycrn",small:"faJyW_doqw"}
var x=(J=Object(k["l"])(_,w,W),J(O=(j=z=function(e){Object(i["a"])(t,e)
var n=Object(c["a"])(t)
function t(){Object(r["a"])(this,t)
return n.apply(this,arguments)}Object(o["a"])(t,[{key:"renderIcon",value:function(){return this.props.checked?d.a.createElement(p,{className:w.iconSVG}):d.a.createElement(v,{className:w.iconSVG})}},{key:"renderLabel",value:function(){var e
var n=this.props,t=n.children,r=n.labelPlacement
var o=(e={},Object(a["a"])(e,w.label,true),Object(a["a"])(e,w.top,"top"===r),Object(a["a"])(e,w.start,"start"===r),Object(a["a"])(e,w.end,"end"===r),e)
return d.a.createElement("span",{className:f()(o)},t)}},{key:"render",value:function(){var e
var n=this.props,t=n.size,r=n.checked,o=n.disabled,i=n.focused,c=n.labelPlacement
var l=(e={},Object(a["a"])(e,w.facade,true),Object(a["a"])(e,w.checked,r),Object(a["a"])(e,w.disabled,o),Object(a["a"])(e,w.focused,i),Object(a["a"])(e,w.top,"top"===c),Object(a["a"])(e,w.start,"start"===c),Object(a["a"])(e,w.end,"end"===c),Object(a["a"])(e,w[t],true),e)
var s=Object(a["a"])({},w.root,true)
"top"===c&&(s[w.top]=true)
return d.a.createElement("span",{className:f()(s)},("top"===c||"start"===c)&&this.renderLabel(),d.a.createElement("span",{className:f()(l),"aria-hidden":"true"},d.a.createElement("span",{className:w.icon},d.a.createElement("span",{className:w.iconToggle},this.renderIcon()))),"end"===c&&this.renderLabel())}}])
t.displayName="ToggleFacade"
return t}(l["Component"]),z.propTypes={children:h.a.node.isRequired,checked:h.a.bool,disabled:h.a.bool,readOnly:h.a.bool,focused:h.a.bool,size:h.a.oneOf(["small","medium","large"]),labelPlacement:h.a.oneOf(["top","start","end"])},z.defaultProps={checked:false,focused:false,size:"medium",disabled:false,readOnly:false,labelPlacement:"end"},j))||O)}}])

//# sourceMappingURL=14-c-ddaf83e06c.js.map